namespace CuoiKyWinForms;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Contains("--test-connection", StringComparer.OrdinalIgnoreCase))
        {
            var serverArgument = args.FirstOrDefault(x => x.StartsWith("--server=", StringComparison.OrdinalIgnoreCase));
            var server = serverArgument is null ? Db.DefaultServer : serverArgument["--server=".Length..].Trim();
            return TestConnections(server);
        }

        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
        return 0;
    }

    private static int TestConnections(string server)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        var databases = new[]
        {
            Db.LibraryDatabase,
            Db.ProjectDatabase,
            Db.GarageDatabase,
            Db.SchoolDatabase
        };

        var failed = false;
        foreach (var database in databases)
        {
            try
            {
                using var connection = Db.CreateConnection(server, database);
                connection.Open();
                Console.WriteLine($"OK   {server} / {database}");
            }
            catch (Exception ex)
            {
                failed = true;
                Console.WriteLine($"FAIL {server} / {database}: {ex.Message}");
            }
        }
        return failed ? 1 : 0;
    }
}
