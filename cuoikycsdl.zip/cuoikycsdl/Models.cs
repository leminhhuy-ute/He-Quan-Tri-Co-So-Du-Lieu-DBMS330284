using System.Data;

namespace CuoiKyWinForms;

public sealed record QueryParameter(
    string Name,
    SqlDbType Type,
    string Label,
    string DefaultValue,
    int Size = 0,
    byte Precision = 0,
    byte Scale = 0);

public sealed record ExerciseOption(string Label, string Description, Action<IWin32Window> Open);
