/*
   CUOI KY CSDL - BAI 7 va BAI 8
   CSDL De an: scalar function, inline TVF, multistatement TVF va truy van nhom.
*/

IF DB_ID(N'CuoiKy_DeAn') IS NULL
    EXEC(N'CREATE DATABASE CuoiKy_DeAn');
GO

USE CuoiKy_DeAn;
GO

IF OBJECT_ID(N'dbo.PhongBan', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PhongBan
    (
        MaPB CHAR(4) NOT NULL CONSTRAINT PK_PhongBan PRIMARY KEY,
        TenPB NVARCHAR(100) NOT NULL,
        MaTruongPhong CHAR(9) NULL,
        NgayNhanChuc DATE NULL
    );
END;
GO

IF OBJECT_ID(N'dbo.NhanVien', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.NhanVien
    (
        MaNV CHAR(9) NOT NULL CONSTRAINT PK_NhanVien PRIMARY KEY,
        Ho NVARCHAR(40) NOT NULL,
        TenLot NVARCHAR(40) NULL,
        Ten NVARCHAR(40) NOT NULL,
        NgaySinh DATE NOT NULL,
        DiaChi NVARCHAR(200) NULL,
        Phai NVARCHAR(10) NULL,
        Luong DECIMAL(12,2) NOT NULL,
        MaPB CHAR(4) NOT NULL,
        CONSTRAINT FK_NhanVien_PhongBan FOREIGN KEY (MaPB) REFERENCES dbo.PhongBan(MaPB),
        CONSTRAINT CK_NhanVien_Luong CHECK (Luong >= 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.DuAn', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DuAn
    (
        MaDA CHAR(4) NOT NULL CONSTRAINT PK_DuAn PRIMARY KEY,
        TenDA NVARCHAR(150) NOT NULL,
        DiaDiemDA NVARCHAR(150) NULL,
        MaPB CHAR(4) NOT NULL,
        CONSTRAINT FK_DuAn_PhongBan FOREIGN KEY (MaPB) REFERENCES dbo.PhongBan(MaPB)
    );
END;
GO

IF OBJECT_ID(N'dbo.PhanCong', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PhanCong
    (
        MaNV CHAR(9) NOT NULL,
        MaDA CHAR(4) NOT NULL,
        Time_Total DECIMAL(10,2) NOT NULL,
        CONSTRAINT PK_PhanCong PRIMARY KEY (MaNV, MaDA),
        CONSTRAINT FK_PhanCong_NhanVien FOREIGN KEY (MaNV) REFERENCES dbo.NhanVien(MaNV),
        CONSTRAINT FK_PhanCong_DuAn FOREIGN KEY (MaDA) REFERENCES dbo.DuAn(MaDA),
        CONSTRAINT CK_PhanCong_Time CHECK (Time_Total >= 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.NguoiThan', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.NguoiThan
    (
        MaNV CHAR(9) NOT NULL,
        TenNguoiThan NVARCHAR(100) NOT NULL,
        NgaySinh DATE NULL,
        Phai NVARCHAR(10) NULL,
        QuanHe NVARCHAR(50) NULL,
        CONSTRAINT PK_NguoiThan PRIMARY KEY (MaNV, TenNguoiThan),
        CONSTRAINT FK_NguoiThan_NhanVien FOREIGN KEY (MaNV) REFERENCES dbo.NhanVien(MaNV)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.PhongBan)
BEGIN
    INSERT dbo.PhongBan (MaPB, TenPB, NgayNhanChuc)
    VALUES
        ('P001', N'Phòng kỹ thuật', '2020-01-10'),
        ('P002', N'Phòng kinh doanh', '2021-05-12'),
        ('P003', N'Phòng nhân sự', '2022-08-01'),
        ('P004', N'Phòng tài chính', '2023-02-15'),
        ('P005', N'Phòng nghiên cứu', '2024-01-20');

    INSERT dbo.NhanVien (MaNV, Ho, TenLot, Ten, NgaySinh, DiaChi, Phai, Luong, MaPB)
    VALUES
        ('NV0000001', N'Nguyễn', N'Văn', N'An', '1990-03-15', N'TP.HCM', N'Nam', 42000, 'P001'),
        ('NV0000002', N'Trần', N'Thị', N'Bình', '1992-07-20', N'TP.HCM', N'Nữ', 36000, 'P001'),
        ('NV0000003', N'Lê', N'Minh', N'Chi', '1988-11-02', N'Đồng Nai', N'Nữ', 31000, 'P001'),
        ('NV0000004', N'Phạm', N'Gia', N'Duy', '1995-01-28', N'Bình Dương', N'Nam', 50000, 'P002'),
        ('NV0000005', N'Hoàng', N'Thanh', N'Hoa', '1991-09-09', N'TP.HCM', N'Nữ', 28000, 'P002'),
        ('NV0000006', N'Vũ', N'Đức', N'Khang', '1994-06-17', N'TP.HCM', N'Nam', 33000, 'P002'),
        ('NV0000007', N'Đỗ', N'Ngọc', N'Lan', '1993-12-01', N'TP.HCM', N'Nữ', 29000, 'P003'),
        ('NV0000008', N'Bùi', N'Quang', N'Minh', '1987-02-26', N'TP.HCM', N'Nam', 27000, 'P003'),
        ('NV0000009', N'Đặng', N'Thùy', N'Dương', '1996-05-30', N'Hà Nội', N'Nữ', 26000, 'P004'),
        ('NV0000010', N'Ngô', N'Hoàng', N'Nam', '1989-08-12', N'Hà Nội', N'Nam', 55000, 'P005'),
        ('NV0000011', N'Phan', N'Mai', N'Ly', '1990-10-04', N'Hà Nội', N'Nữ', 47000, 'P005'),
        ('NV0000012', N'Đinh', N'Văn', N'Thái', '1992-04-22', N'Hà Nội', N'Nam', 38000, 'P005');

    UPDATE dbo.PhongBan SET MaTruongPhong = 'NV0000001' WHERE MaPB = 'P001';
    UPDATE dbo.PhongBan SET MaTruongPhong = 'NV0000004' WHERE MaPB = 'P002';
    UPDATE dbo.PhongBan SET MaTruongPhong = 'NV0000007' WHERE MaPB = 'P003';
    UPDATE dbo.PhongBan SET MaTruongPhong = 'NV0000009' WHERE MaPB = 'P004';
    UPDATE dbo.PhongBan SET MaTruongPhong = 'NV0000010' WHERE MaPB = 'P005';

    INSERT dbo.DuAn (MaDA, TenDA, DiaDiemDA, MaPB)
    VALUES
        ('DA01', N'Xây dựng cổng thông tin', N'TP.HCM', 'P001'),
        ('DA02', N'Ứng dụng quản lý thư viện', N'TP.HCM', 'P001'),
        ('DA03', N'Chiến dịch khách hàng mới', N'Hà Nội', 'P002'),
        ('DA04', N'Đào tạo nội bộ', N'TP.HCM', 'P003'),
        ('DA05', N'Nền tảng phân tích dữ liệu', N'Hà Nội', 'P005');

    INSERT dbo.PhanCong (MaNV, MaDA, Time_Total)
    VALUES
        ('NV0000001', 'DA01', 30), ('NV0000002', 'DA01', 60), ('NV0000003', 'DA01', 100),
        ('NV0000001', 'DA02', 75), ('NV0000002', 'DA02', 40),
        ('NV0000004', 'DA03', 150), ('NV0000005', 'DA03', 20), ('NV0000006', 'DA03', 80),
        ('NV0000007', 'DA04', 45), ('NV0000008', 'DA04', 60),
        ('NV0000010', 'DA05', 120), ('NV0000011', 'DA05', 90), ('NV0000012', 'DA05', 30);

    INSERT dbo.NguoiThan (MaNV, TenNguoiThan, NgaySinh, Phai, QuanHe)
    VALUES
        ('NV0000001', N'Nguyễn Minh Khang', '2015-04-10', N'Nam', N'Con'),
        ('NV0000001', N'Trần Ngọc Mai', '1992-06-18', N'Nữ', N'Vợ'),
        ('NV0000002', N'Lê Gia Hân', '2018-02-11', N'Nữ', N'Con'),
        ('NV0000004', N'Phạm Văn Long', '1985-12-12', N'Nam', N'Chồng'),
        ('NV0000010', N'Ngô Anh Tú', '2014-09-21', N'Nam', N'Con');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_PhongBan_TruongPhong')
    ALTER TABLE dbo.PhongBan ADD CONSTRAINT FK_PhongBan_TruongPhong
        FOREIGN KEY (MaTruongPhong) REFERENCES dbo.NhanVien(MaNV);
GO

CREATE OR ALTER FUNCTION dbo.fn_LuongTBPhongBan (@MaPB CHAR(4))
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @KetQua DECIMAL(18,2);
    SELECT @KetQua = AVG(CAST(Luong AS DECIMAL(18,2))) FROM dbo.NhanVien WHERE MaPB = @MaPB;
    RETURN @KetQua;
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_TongLuongNhanVienTheoDuAn
(
    @MaNV CHAR(9),
    @MaDA CHAR(4)
)
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @KetQua DECIMAL(18,2);
    SELECT @KetQua = SUM(CAST(nv.Luong * pc.Time_Total AS DECIMAL(18,2)))
    FROM dbo.NhanVien nv INNER JOIN dbo.PhanCong pc ON pc.MaNV = nv.MaNV
    WHERE pc.MaNV = @MaNV AND pc.MaDA = @MaDA;
    RETURN ISNULL(@KetQua, 0);
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_LuongTBAllPhongBan ()
RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @KetQua DECIMAL(18,2);
    SELECT @KetQua = AVG(CAST(TB.TongLuongTB AS DECIMAL(18,2)))
    FROM
    (
        SELECT MaPB, AVG(CAST(Luong AS DECIMAL(18,2))) AS TongLuongTB
        FROM dbo.NhanVien GROUP BY MaPB
    ) TB;
    RETURN @KetQua;
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_TienThuongTheoGio (@Time_Total DECIMAL(10,2))
RETURNS DECIMAL(12,2)
AS
BEGIN
    DECLARE @TienThuong DECIMAL(12,2) = 0;
    IF @Time_Total >= 30 AND @Time_Total <= 60 SET @TienThuong = 500;
    ELSE IF @Time_Total > 60 AND @Time_Total < 100 SET @TienThuong = 1000;
    ELSE IF @Time_Total >= 100 AND @Time_Total < 150 SET @TienThuong = 1200;
    ELSE IF @Time_Total >= 150 SET @TienThuong = 1600;
    RETURN @TienThuong;
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_TongDuAnTheoPhongBan (@MaPB CHAR(4))
RETURNS INT
AS
BEGIN
    DECLARE @SoDuAn INT;
    SELECT @SoDuAn = COUNT(*) FROM dbo.DuAn WHERE MaPB = @MaPB;
    RETURN ISNULL(@SoDuAn, 0);
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_ThongTinNhanVien_ITVF ()
RETURNS TABLE
AS
RETURN
(
    SELECT nv.MaNV,
           LTRIM(RTRIM(CONCAT(nv.Ho, N' ', nv.TenLot, N' ', nv.Ten))) AS HoTen,
           nv.NgaySinh,
           ISNULL(nt.NguoiThan, N'') AS NguoiThan,
           CAST(pb.TongLuongTB AS DECIMAL(18,2)) AS TongLuongTB
    FROM dbo.NhanVien nv
    CROSS APPLY
    (
        SELECT AVG(CAST(nv2.Luong AS DECIMAL(18,2))) AS TongLuongTB
        FROM dbo.NhanVien nv2 WHERE nv2.MaPB = nv.MaPB
    ) pb
    OUTER APPLY
    (
        SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), nt2.TenNguoiThan), N', ')
               WITHIN GROUP (ORDER BY nt2.TenNguoiThan) AS NguoiThan
        FROM dbo.NguoiThan nt2 WHERE nt2.MaNV = nv.MaNV
    ) nt
);
GO

CREATE OR ALTER FUNCTION dbo.fn_ThongTinNhanVien_MSTVF ()
RETURNS @KetQua TABLE
(
    MaNV CHAR(9) NOT NULL PRIMARY KEY,
    HoTen NVARCHAR(130) NOT NULL,
    NgaySinh DATE NOT NULL,
    NguoiThan NVARCHAR(MAX) NULL,
    TongLuongTB DECIMAL(18,2) NULL
)
AS
BEGIN
    INSERT @KetQua (MaNV, HoTen, NgaySinh, NguoiThan, TongLuongTB)
    SELECT nv.MaNV,
           LTRIM(RTRIM(CONCAT(nv.Ho, N' ', nv.TenLot, N' ', nv.Ten))),
           nv.NgaySinh,
           ISNULL(nt.NguoiThan, N''),
           CAST(pb.TongLuongTB AS DECIMAL(18,2))
    FROM dbo.NhanVien nv
    CROSS APPLY
    (
        SELECT AVG(CAST(nv2.Luong AS DECIMAL(18,2))) AS TongLuongTB
        FROM dbo.NhanVien nv2 WHERE nv2.MaPB = nv.MaPB
    ) pb
    OUTER APPLY
    (
        SELECT STRING_AGG(CONVERT(NVARCHAR(MAX), nt2.TenNguoiThan), N', ')
               WITHIN GROUP (ORDER BY nt2.TenNguoiThan) AS NguoiThan
        FROM dbo.NguoiThan nt2 WHERE nt2.MaNV = nv.MaNV
    ) nt;
    RETURN;
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_DuAnNhieuHonHaiNhanVien ()
RETURNS TABLE
AS
RETURN
(
    SELECT da.MaDA, da.TenDA, COUNT(pc.MaNV) AS SoLuongNhanVien
    FROM dbo.DuAn da LEFT JOIN dbo.PhanCong pc ON pc.MaDA = da.MaDA
    GROUP BY da.MaDA, da.TenDA
    HAVING COUNT(pc.MaNV) > 2
);
GO

CREATE OR ALTER FUNCTION dbo.fn_PhongNhieuHonHaiNhanVienLuongCao ()
RETURNS TABLE
AS
RETURN
(
    SELECT MaPB,
           SUM(CASE WHEN Luong > 25000 THEN 1 ELSE 0 END) AS SoNhanVienLuongLonHon25000
    FROM dbo.NhanVien
    GROUP BY MaPB
    HAVING COUNT(*) > 2
);
GO

CREATE OR ALTER FUNCTION dbo.fn_PhongLuongTBCao ()
RETURNS TABLE
AS
RETURN
(
    SELECT pb.MaPB, pb.TenPB, COUNT(nv.MaNV) AS SoLuongNhanVien
    FROM dbo.PhongBan pb INNER JOIN dbo.NhanVien nv ON nv.MaPB = pb.MaPB
    GROUP BY pb.MaPB, pb.TenPB
    HAVING AVG(nv.Luong) > 30000
);
GO

CREATE OR ALTER FUNCTION dbo.fn_PhongLuongTBCao_Nam ()
RETURNS TABLE
AS
RETURN
(
    SELECT pb.MaPB, pb.TenPB,
           SUM(CASE WHEN nv.Phai = N'Nam' THEN 1 ELSE 0 END) AS SoLuongNhanVienNam
    FROM dbo.PhongBan pb INNER JOIN dbo.NhanVien nv ON nv.MaPB = pb.MaPB
    GROUP BY pb.MaPB, pb.TenPB
    HAVING AVG(nv.Luong) > 30000
);
GO

CREATE OR ALTER FUNCTION dbo.fn_DuAnVaNhanVienPhong5 ()
RETURNS TABLE
AS
RETURN
(
    SELECT da.MaDA, da.TenDA,
           SUM(CASE WHEN nv.MaPB = 'P005' THEN 1 ELSE 0 END) AS SoNhanVienPhong5
    FROM dbo.DuAn da
    LEFT JOIN dbo.PhanCong pc ON pc.MaDA = da.MaDA
    LEFT JOIN dbo.NhanVien nv ON nv.MaNV = pc.MaNV
    GROUP BY da.MaDA, da.TenDA
);
GO
