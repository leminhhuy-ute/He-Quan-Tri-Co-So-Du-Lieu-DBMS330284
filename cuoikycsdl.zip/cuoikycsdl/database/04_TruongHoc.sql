/*
   CUOI KY CSDL - BAI 10
   CSDL truong pho thong: mon hoc, buoi thi va phan cong coi thi.
*/

IF DB_ID(N'CuoiKy_TruongHoc') IS NULL
    EXEC(N'CREATE DATABASE CuoiKy_TruongHoc');
GO

USE CuoiKy_TruongHoc;
GO

IF OBJECT_ID(N'dbo.MHOC', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.MHOC
    (
        MAMH CHAR(4) NOT NULL CONSTRAINT PK_MHOC PRIMARY KEY,
        TENMH NVARCHAR(100) NOT NULL,
        SOTIET INT NOT NULL,
        CONSTRAINT CK_MHOC_SoTiet CHECK (SOTIET > 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.GV', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.GV
    (
        MAGV CHAR(5) NOT NULL CONSTRAINT PK_GV PRIMARY KEY,
        TENGV NVARCHAR(120) NOT NULL,
        MAMH CHAR(4) NULL,
        CONSTRAINT FK_GV_MHOC FOREIGN KEY (MAMH) REFERENCES dbo.MHOC(MAMH)
    );
END;
GO

IF OBJECT_ID(N'dbo.BUOITHI', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.BUOITHI
    (
        HKY TINYINT NOT NULL,
        NGAY DATE NOT NULL,
        GIO TIME(0) NOT NULL,
        PHG VARCHAR(10) NOT NULL,
        MAMH CHAR(4) NOT NULL,
        TGTHI INT NOT NULL,
        CONSTRAINT PK_BUOITHI PRIMARY KEY (HKY, NGAY, GIO, PHG),
        CONSTRAINT FK_BUOITHI_MHOC FOREIGN KEY (MAMH) REFERENCES dbo.MHOC(MAMH),
        CONSTRAINT CK_BUOITHI_HKY CHECK (HKY IN (1, 2)),
        CONSTRAINT CK_BUOITHI_TGTHI CHECK (TGTHI > 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.PC_COI_THI', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PC_COI_THI
    (
        MAGV CHAR(5) NOT NULL,
        HK TINYINT NOT NULL,
        NGAY DATE NOT NULL,
        GIO TIME(0) NOT NULL,
        PHG VARCHAR(10) NOT NULL,
        CONSTRAINT PK_PC_COI_THI PRIMARY KEY (MAGV, HK, NGAY, GIO, PHG),
        CONSTRAINT FK_PC_GV FOREIGN KEY (MAGV) REFERENCES dbo.GV(MAGV),
        CONSTRAINT FK_PC_BUOITHI FOREIGN KEY (HK, NGAY, GIO, PHG) REFERENCES dbo.BUOITHI(HKY, NGAY, GIO, PHG),
        CONSTRAINT CK_PC_HK CHECK (HK IN (1, 2))
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.MHOC)
BEGIN
    INSERT dbo.MHOC (MAMH, TENMH, SOTIET)
    VALUES ('M001', N'TOÁN', 30),
           ('M002', N'VĂN HỌC', 45),
           ('M003', N'VẬT LÝ', 45),
           ('M004', N'HÓA HỌC', 60),
           ('M005', N'TIN HỌC', 30);

    INSERT dbo.GV (MAGV, TENGV, MAMH)
    VALUES ('GV001', N'Nguyễn Minh An', 'M001'),
           ('GV002', N'Trần Thị Bình', 'M002'),
           ('GV003', N'Lê Quốc Cường', NULL),
           ('GV004', N'Phạm Gia Duy', 'M003'),
           ('GV005', N'Hoàng Thanh Hoa', NULL);

    INSERT dbo.BUOITHI (HKY, NGAY, GIO, PHG, MAMH, TGTHI)
    VALUES (1, '2026-09-15', '07:30', 'A101', 'M001', 120),
           (1, '2026-09-16', '07:30', 'A102', 'M002', 150),
           (1, '2026-09-17', '13:30', 'A103', 'M003', 150),
           (1, '2026-09-18', '07:30', 'A104', 'M004', 150),
           (2, '2027-01-10', '07:30', 'B201', 'M005', 120);

    INSERT dbo.PC_COI_THI (MAGV, HK, NGAY, GIO, PHG)
    VALUES ('GV001', 1, '2026-09-16', '07:30', 'A102'),
           ('GV002', 1, '2026-09-15', '07:30', 'A101'),
           ('GV003', 1, '2026-09-15', '07:30', 'A101'),
           ('GV004', 1, '2026-09-16', '07:30', 'A102'),
           ('GV002', 2, '2027-01-10', '07:30', 'B201');
END;
GO

CREATE OR ALTER TRIGGER dbo.tg_BuoiThi_ThoiGian
ON dbo.BUOITHI
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM inserted i INNER JOIN dbo.MHOC mh ON mh.MAMH = i.MAMH
        WHERE (mh.SOTIET = 30 AND i.TGTHI <> 120)
           OR (mh.SOTIET >= 45 AND i.TGTHI <> 150)
    )
        THROW 51001, N'Ràng buộc thời gian thi không phù hợp với số tiết môn học.', 1;
END;
GO

CREATE OR ALTER TRIGGER dbo.tg_PC_CoiThi_KiemTra
ON dbo.PC_COI_THI
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM inserted i
        INNER JOIN dbo.BUOITHI bt ON bt.HKY = i.HK
            AND bt.NGAY = i.NGAY AND bt.GIO = i.GIO AND bt.PHG = i.PHG
        INNER JOIN dbo.GV gv ON gv.MAGV = i.MAGV
        WHERE gv.MAMH IS NOT NULL AND gv.MAMH = bt.MAMH
    )
        THROW 51002, N'Giáo viên không được coi thi môn mình chủ nhiệm.', 1;
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_GiaoVienDayMon45 ()
RETURNS TABLE
AS
RETURN
(
    SELECT gv.MAGV, gv.TENGV, mh.MAMH, mh.TENMH, mh.SOTIET
    FROM dbo.GV gv INNER JOIN dbo.MHOC mh ON mh.MAMH = gv.MAMH
    WHERE mh.SOTIET >= 45
);
GO

CREATE OR ALTER FUNCTION dbo.fn_GiaoVienGacThiHK1 ()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT gv.MAGV, gv.TENGV
    FROM dbo.GV gv INNER JOIN dbo.PC_COI_THI pc ON pc.MAGV = gv.MAGV
    WHERE pc.HK = 1
);
GO

CREATE OR ALTER FUNCTION dbo.fn_GiaoVienKhongGacThiHK1 ()
RETURNS TABLE
AS
RETURN
(
    SELECT gv.MAGV, gv.TENGV
    FROM dbo.GV gv
    WHERE NOT EXISTS
    (
        SELECT 1 FROM dbo.PC_COI_THI pc WHERE pc.MAGV = gv.MAGV AND pc.HK = 1
    )
);
GO

CREATE OR ALTER FUNCTION dbo.fn_LichThiMonVan ()
RETURNS TABLE
AS
RETURN
(
    SELECT bt.HKY, bt.NGAY, bt.GIO, bt.PHG, mh.MAMH, mh.TENMH, bt.TGTHI
    FROM dbo.BUOITHI bt INNER JOIN dbo.MHOC mh ON mh.MAMH = bt.MAMH
    WHERE mh.TENMH = N'VĂN HỌC'
);
GO

CREATE OR ALTER FUNCTION dbo.fn_GacThiChuNhiemVan ()
RETURNS TABLE
AS
RETURN
(
    SELECT gv.MAGV, gv.TENGV, bt.HKY, bt.NGAY, bt.GIO, bt.PHG,
           mh.MAMH, mh.TENMH AS MonThi, bt.TGTHI
    FROM dbo.GV gv
    INNER JOIN dbo.MHOC monChuNhiem ON monChuNhiem.MAMH = gv.MAMH
    INNER JOIN dbo.PC_COI_THI pc ON pc.MAGV = gv.MAGV
    INNER JOIN dbo.BUOITHI bt ON bt.HKY = pc.HK
        AND bt.NGAY = pc.NGAY AND bt.GIO = pc.GIO AND bt.PHG = pc.PHG
    INNER JOIN dbo.MHOC mh ON mh.MAMH = bt.MAMH
    WHERE monChuNhiem.TENMH = N'VĂN HỌC'
);
GO
