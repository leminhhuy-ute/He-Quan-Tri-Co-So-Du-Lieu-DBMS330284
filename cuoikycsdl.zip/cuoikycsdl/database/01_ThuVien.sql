/*
   CUOI KY CSDL - BAI 1 den BAI 6
   CSDL Thu vien: phuong trinh, thong tin sach/doc gia va trigger.
   Chay toan bo file tren SQL Server/LocalDB.
*/

IF DB_ID(N'CuoiKy_ThuVien') IS NULL
    EXEC(N'CREATE DATABASE CuoiKy_ThuVien');
GO

USE CuoiKy_ThuVien;
GO

IF OBJECT_ID(N'dbo.DocGia', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DocGia
    (
        ma_DocGia INT NOT NULL CONSTRAINT PK_DocGia PRIMARY KEY,
        ho NVARCHAR(50) NOT NULL,
        tenlot NVARCHAR(50) NULL,
        ten NVARCHAR(50) NOT NULL,
        ngaysinh DATE NOT NULL
    );
END;
GO

IF OBJECT_ID(N'dbo.Nguoilon', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Nguoilon
    (
        ma_DocGia INT NOT NULL CONSTRAINT PK_Nguoilon PRIMARY KEY,
        sonha NVARCHAR(20) NULL,
        duong NVARCHAR(100) NULL,
        quan NVARCHAR(80) NULL,
        dienthoai VARCHAR(20) NULL,
        han_sd DATE NULL,
        CONSTRAINT FK_Nguoilon_DocGia FOREIGN KEY (ma_DocGia) REFERENCES dbo.DocGia(ma_DocGia)
    );
END;
GO

IF OBJECT_ID(N'dbo.Treem', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Treem
    (
        ma_DocGia INT NOT NULL CONSTRAINT PK_Treem PRIMARY KEY,
        ma_DocGia_nguoilon INT NOT NULL,
        CONSTRAINT FK_Treem_DocGia FOREIGN KEY (ma_DocGia) REFERENCES dbo.DocGia(ma_DocGia),
        CONSTRAINT FK_Treem_NguoiLon FOREIGN KEY (ma_DocGia_nguoilon) REFERENCES dbo.Nguoilon(ma_DocGia),
        CONSTRAINT CK_Treem_KhacNguoiLon CHECK (ma_DocGia <> ma_DocGia_nguoilon)
    );
END;
GO

IF OBJECT_ID(N'dbo.Tuasach', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Tuasach
    (
        ma_tuasach INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Tuasach PRIMARY KEY,
        tuasach NVARCHAR(200) NOT NULL,
        tacgia NVARCHAR(150) NOT NULL,
        tomtat NVARCHAR(1000) NULL
    );
END;
GO

IF OBJECT_ID(N'dbo.Dausach', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Dausach
    (
        isbn VARCHAR(20) NOT NULL CONSTRAINT PK_Dausach PRIMARY KEY,
        ma_tuasach INT NOT NULL,
        ngonngu NVARCHAR(50) NULL,
        bia NVARCHAR(100) NULL,
        trangthai VARCHAR(10) NOT NULL CONSTRAINT DF_Dausach_TrangThai DEFAULT ('yes'),
        CONSTRAINT FK_Dausach_Tuasach FOREIGN KEY (ma_tuasach) REFERENCES dbo.Tuasach(ma_tuasach),
        CONSTRAINT CK_Dausach_TrangThai CHECK (trangthai IN ('yes', 'no'))
    );
END;
GO

IF OBJECT_ID(N'dbo.Cuonsach', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Cuonsach
    (
        isbn VARCHAR(20) NOT NULL,
        ma_cuonsach INT NOT NULL,
        tinhtrang VARCHAR(10) NOT NULL CONSTRAINT DF_Cuonsach_TinhTrang DEFAULT ('yes'),
        CONSTRAINT PK_Cuonsach PRIMARY KEY (isbn, ma_cuonsach),
        CONSTRAINT FK_Cuonsach_Dausach FOREIGN KEY (isbn) REFERENCES dbo.Dausach(isbn),
        CONSTRAINT CK_Cuonsach_TinhTrang CHECK (tinhtrang IN ('yes', 'no'))
    );
END;
GO

IF OBJECT_ID(N'dbo.DangKy', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DangKy
    (
        isbn VARCHAR(20) NOT NULL,
        ma_DocGia INT NOT NULL,
        ngay_dk DATE NOT NULL,
        ghichu NVARCHAR(250) NULL,
        CONSTRAINT PK_DangKy PRIMARY KEY (isbn, ma_DocGia, ngay_dk),
        CONSTRAINT FK_DangKy_Dausach FOREIGN KEY (isbn) REFERENCES dbo.Dausach(isbn),
        CONSTRAINT FK_DangKy_DocGia FOREIGN KEY (ma_DocGia) REFERENCES dbo.DocGia(ma_DocGia)
    );
END;
GO

IF OBJECT_ID(N'dbo.Muon', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Muon
    (
        isbn VARCHAR(20) NOT NULL,
        ma_cuonsach INT NOT NULL,
        ma_DocGia INT NOT NULL,
        ngay_muon DATE NOT NULL,
        ngay_hethan DATE NOT NULL,
        CONSTRAINT PK_Muon PRIMARY KEY (isbn, ma_cuonsach),
        CONSTRAINT FK_Muon_Cuonsach FOREIGN KEY (isbn, ma_cuonsach) REFERENCES dbo.Cuonsach(isbn, ma_cuonsach),
        CONSTRAINT FK_Muon_DocGia FOREIGN KEY (ma_DocGia) REFERENCES dbo.DocGia(ma_DocGia),
        CONSTRAINT CK_Muon_Ngay CHECK (ngay_hethan >= ngay_muon)
    );
END;
GO

IF OBJECT_ID(N'dbo.QuaTrinhMuon', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.QuaTrinhMuon
    (
        isbn VARCHAR(20) NOT NULL,
        ma_cuonsach INT NOT NULL,
        ngay_muon DATE NOT NULL,
        ma_DocGia INT NOT NULL,
        ngay_hethan DATE NOT NULL,
        ngay_tra DATE NULL,
        tien_muon DECIMAL(12,2) NOT NULL CONSTRAINT DF_QTM_TienMuon DEFAULT (0),
        tien_datra DECIMAL(12,2) NOT NULL CONSTRAINT DF_QTM_TienDaTra DEFAULT (0),
        tien_datcoc DECIMAL(12,2) NOT NULL CONSTRAINT DF_QTM_TienDatCoc DEFAULT (0),
        ghichu NVARCHAR(250) NULL,
        CONSTRAINT PK_QuaTrinhMuon PRIMARY KEY (isbn, ma_cuonsach, ngay_muon, ma_DocGia),
        CONSTRAINT FK_QTM_Cuonsach FOREIGN KEY (isbn, ma_cuonsach) REFERENCES dbo.Cuonsach(isbn, ma_cuonsach),
        CONSTRAINT FK_QTM_DocGia FOREIGN KEY (ma_DocGia) REFERENCES dbo.DocGia(ma_DocGia),
        CONSTRAINT CK_QTM_Ngay CHECK (ngay_tra IS NULL OR ngay_tra >= ngay_muon),
        CONSTRAINT CK_QTM_Tien CHECK (tien_muon >= 0 AND tien_datra >= 0 AND tien_datcoc >= 0)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.DocGia)
BEGIN
    INSERT dbo.DocGia (ma_DocGia, ho, tenlot, ten, ngaysinh)
    VALUES
        (1, N'Nguyễn', N'Văn', N'An', '1998-04-12'),
        (2, N'Trần', N'Thị', N'Bình', '2001-09-08'),
        (3, N'Lê', N'Minh', N'Chi', '2014-02-20'),
        (4, N'Phạm', N'Gia', N'Duy', '2016-11-03'),
        (5, N'Hoàng', N'Thanh', N'Hoa', '1995-07-25'),
        (6, N'Võ', N'Ngọc', N'Lâm', '2013-06-16');

    INSERT dbo.Nguoilon (ma_DocGia, sonha, duong, quan, dienthoai, han_sd)
    VALUES
        (1, N'12', N'Nguyễn Trãi', N'Quận 1', '0901000001', '2027-12-31'),
        (2, N'45', N'Lê Lợi', N'Quận 3', '0901000002', '2027-12-31'),
        (5, N'88', N'Phạm Văn Đồng', N'Gò Vấp', '0901000005', '2028-06-30');

    INSERT dbo.Treem (ma_DocGia, ma_DocGia_nguoilon)
    VALUES (3, 1), (4, 2), (6, 5);

    INSERT dbo.Tuasach (tuasach, tacgia, tomtat)
    VALUES
        (N'Lập trình SQL Server', N'Nguyễn Văn A', N'Kiến thức về cơ sở dữ liệu quan hệ và T-SQL.'),
        (N'Lập trình C# căn bản', N'Trần Thị B', N'C# và Windows Forms cho người mới bắt đầu.'),
        (N'Nhập môn thuật toán', N'Lê Minh C', N'Các cấu trúc dữ liệu và thuật toán cơ bản.');

    INSERT dbo.Dausach (isbn, ma_tuasach, ngonngu, bia, trangthai)
    SELECT 'ISBN001', ma_tuasach, N'Tiếng Việt', N'Bìa mềm', 'yes' FROM dbo.Tuasach WHERE tuasach = N'Lập trình SQL Server'
    UNION ALL
    SELECT 'ISBN002', ma_tuasach, N'Tiếng Việt', N'Bìa mềm', 'yes' FROM dbo.Tuasach WHERE tuasach = N'Lập trình C# căn bản'
    UNION ALL
    SELECT 'ISBN003', ma_tuasach, N'Tiếng Việt', N'Bìa cứng', 'yes' FROM dbo.Tuasach WHERE tuasach = N'Nhập môn thuật toán';

    INSERT dbo.Cuonsach (isbn, ma_cuonsach, tinhtrang)
    VALUES
        ('ISBN001', 1, 'no'), ('ISBN001', 2, 'yes'),
        ('ISBN002', 1, 'no'), ('ISBN002', 2, 'yes'),
        ('ISBN003', 1, 'no'), ('ISBN003', 2, 'yes');

    INSERT dbo.DangKy (isbn, ma_DocGia, ngay_dk, ghichu)
    VALUES
        ('ISBN001', 1, '2026-08-01', N'Đăng ký online'),
        ('ISBN002', 2, '2026-08-02', NULL),
        ('ISBN003', 3, '2026-08-03', NULL);

    INSERT dbo.Muon (isbn, ma_cuonsach, ma_DocGia, ngay_muon, ngay_hethan)
    VALUES
        ('ISBN002', 1, 1, DATEADD(DAY, -20, CONVERT(date, GETDATE())), DATEADD(DAY, -6, CONVERT(date, GETDATE()))),
        ('ISBN001', 1, 3, DATEADD(DAY, -2, CONVERT(date, GETDATE())), DATEADD(DAY, 12, CONVERT(date, GETDATE()))),
        ('ISBN003', 1, 5, DATEADD(DAY, -35, CONVERT(date, GETDATE())), DATEADD(DAY, -21, CONVERT(date, GETDATE())));

    INSERT dbo.QuaTrinhMuon (isbn, ma_cuonsach, ngay_muon, ma_DocGia, ngay_hethan, ngay_tra, tien_muon, tien_datra, tien_datcoc, ghichu)
    VALUES
        ('ISBN002', 1, DATEADD(DAY, -45, CONVERT(date, GETDATE())), 2, DATEADD(DAY, -31, CONVERT(date, GETDATE())), DATEADD(DAY, -25, CONVERT(date, GETDATE())), 10000, 10000, 50000, N'Đã trả'),
        ('ISBN001', 1, DATEADD(DAY, -2, CONVERT(date, GETDATE())), 3, DATEADD(DAY, 12, CONVERT(date, GETDATE())), NULL, 10000, 0, 50000, N'Đang mượn');
END;
GO

UPDATE ds
SET trangthai = CASE WHEN EXISTS
    (SELECT 1 FROM dbo.Cuonsach cs WHERE cs.isbn = ds.isbn AND cs.tinhtrang = 'yes') THEN 'yes' ELSE 'no' END
FROM dbo.Dausach ds;
GO

CREATE OR ALTER FUNCTION dbo.fn_TinhTuoi (@NamSinh INT)
RETURNS INT
AS
BEGIN
    IF @NamSinh IS NULL OR @NamSinh < 1 OR @NamSinh > YEAR(GETDATE())
        RETURN NULL;
    RETURN YEAR(GETDATE()) - @NamSinh;
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_GiaiPTBac2
(
    @a DECIMAL(18,6),
    @b DECIMAL(18,6),
    @c DECIMAL(18,6)
)
RETURNS NVARCHAR(400)
AS
BEGIN
    DECLARE @delta FLOAT = CONVERT(FLOAT, @b) * CONVERT(FLOAT, @b)
                         - 4.0 * CONVERT(FLOAT, @a) * CONVERT(FLOAT, @c);
    DECLARE @ketqua NVARCHAR(400);

    IF @a = 0
        RETURN CASE WHEN @b = 0 AND @c = 0 THEN N'Vô số nghiệm'
                    WHEN @b = 0 THEN N'Vô nghiệm'
                    ELSE CONCAT(N'Phương trình bậc nhất: x = ', CONVERT(NVARCHAR(80), CAST(-@c / @b AS DECIMAL(18,6)))) END;

    IF @delta < 0
        RETURN N'Vô nghiệm thực';

    IF @delta = 0
        RETURN CONCAT(N'Nghiệm kép x1 = x2 = ', CONVERT(NVARCHAR(80), CAST(-@b / (2 * @a) AS DECIMAL(18,6))));

    SET @ketqua = CONCAT(
        N'x1 = ', CONVERT(NVARCHAR(80), CAST((-CONVERT(FLOAT, @b) + SQRT(@delta)) / (2 * CONVERT(FLOAT, @a)) AS DECIMAL(18,6))),
        N'; x2 = ', CONVERT(NVARCHAR(80), CAST((-CONVERT(FLOAT, @b) - SQRT(@delta)) / (2 * CONVERT(FLOAT, @a)) AS DECIMAL(18,6))));
    RETURN @ketqua;
END;
GO

CREATE OR ALTER PROCEDURE dbo.sp_GiaiPTBac1
    @a DECIMAL(18,6),
    @b DECIMAL(18,6)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @a AS a, @b AS b,
           CASE WHEN @a = 0 AND @b = 0 THEN N'Vô số nghiệm'
                WHEN @a = 0 THEN N'Vô nghiệm'
                ELSE N'Nghiệm duy nhất' END AS KetLuan,
           CASE WHEN @a = 0 THEN NULL ELSE CAST(-@b / @a AS DECIMAL(18,6)) END AS NghiemX;
END;
GO

CREATE OR ALTER PROCEDURE dbo.sp_ThongtinDausach
    @ISBN VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ds.isbn, ds.ma_tuasach, ts.tuasach, ts.tacgia, ts.tomtat,
           ds.ngonngu, ds.bia, ds.trangthai,
           (SELECT COUNT(*) FROM dbo.Cuonsach cs
            WHERE cs.isbn = ds.isbn AND cs.tinhtrang = 'yes') AS SoLuongChuaMuon
    FROM dbo.Dausach ds
    INNER JOIN dbo.Tuasach ts ON ts.ma_tuasach = ds.ma_tuasach
    WHERE ds.isbn = @ISBN;
END;
GO

CREATE OR ALTER PROCEDURE dbo.sp_ThongtinDocGia
    @MaDocGia INT
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM dbo.Nguoilon WHERE ma_DocGia = @MaDocGia)
    BEGIN
        SELECT dg.ma_DocGia, dg.ho, dg.tenlot, dg.ten, dg.ngaysinh,
               nl.sonha, nl.duong, nl.quan, nl.dienthoai, nl.han_sd,
               CAST(N'Người lớn' AS NVARCHAR(20)) AS LoaiDocGia
        FROM dbo.DocGia dg INNER JOIN dbo.Nguoilon nl ON nl.ma_DocGia = dg.ma_DocGia
        WHERE dg.ma_DocGia = @MaDocGia;
        RETURN;
    END;
    IF EXISTS (SELECT 1 FROM dbo.Treem WHERE ma_DocGia = @MaDocGia)
    BEGIN
        SELECT dg.ma_DocGia, dg.ho, dg.tenlot, dg.ten, dg.ngaysinh,
               te.ma_DocGia_nguoilon,
               CAST(N'Trẻ em' AS NVARCHAR(20)) AS LoaiDocGia
        FROM dbo.DocGia dg INNER JOIN dbo.Treem te ON te.ma_DocGia = dg.ma_DocGia
        WHERE dg.ma_DocGia = @MaDocGia;
        RETURN;
    END;
    THROW 50001, N'Mã độc giả không tồn tại hoặc chưa được phân loại.', 1;
END;
GO

CREATE OR ALTER PROCEDURE dbo.sp_ThongtinNguoilonDangmuon
AS
BEGIN
    SET NOCOUNT ON;
    SELECT dg.ma_DocGia, dg.ho, dg.tenlot, dg.ten, dg.ngaysinh,
           nl.sonha, nl.duong, nl.quan, nl.dienthoai, nl.han_sd,
           m.isbn, m.ma_cuonsach, m.ngay_muon, m.ngay_hethan, ts.tuasach
    FROM dbo.Nguoilon nl
    INNER JOIN dbo.DocGia dg ON dg.ma_DocGia = nl.ma_DocGia
    INNER JOIN dbo.Muon m ON m.ma_DocGia = nl.ma_DocGia
    INNER JOIN dbo.Dausach ds ON ds.isbn = m.isbn
    INNER JOIN dbo.Tuasach ts ON ts.ma_tuasach = ds.ma_tuasach
    ORDER BY dg.ma_DocGia, m.ngay_muon;
END;
GO

CREATE OR ALTER PROCEDURE dbo.sp_ThongtinNguoilonQuahan
AS
BEGIN
    SET NOCOUNT ON;
    SELECT dg.ma_DocGia, dg.ho, dg.tenlot, dg.ten, dg.ngaysinh,
           nl.sonha, nl.duong, nl.quan, nl.dienthoai, nl.han_sd,
           m.isbn, m.ma_cuonsach, m.ngay_muon, m.ngay_hethan,
           DATEDIFF(DAY, m.ngay_hethan, CONVERT(date, GETDATE())) AS SoNgayQuaHan,
           ts.tuasach
    FROM dbo.Nguoilon nl
    INNER JOIN dbo.DocGia dg ON dg.ma_DocGia = nl.ma_DocGia
    INNER JOIN dbo.Muon m ON m.ma_DocGia = nl.ma_DocGia
    INNER JOIN dbo.Dausach ds ON ds.isbn = m.isbn
    INNER JOIN dbo.Tuasach ts ON ts.ma_tuasach = ds.ma_tuasach
    WHERE DATEDIFF(DAY, m.ngay_hethan, CONVERT(date, GETDATE())) > 14
    ORDER BY dg.ma_DocGia, m.ngay_hethan;
END;
GO

CREATE OR ALTER PROCEDURE dbo.sp_DocGiaCoTreEmMuon
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DISTINCT nl.ma_DocGia AS MaNguoiLon,
           CONCAT(dgNL.ho, N' ', dgNL.tenlot, N' ', dgNL.ten) AS HoTenNguoiLon,
           te.ma_DocGia AS MaTreEm,
           CONCAT(dgTE.ho, N' ', dgTE.tenlot, N' ', dgTE.ten) AS HoTenTreEm,
           mNL.isbn AS ISBNNguoiLon, mNL.ma_cuonsach AS CuonNguoiLon,
           mTE.isbn AS ISBNTreEm, mTE.ma_cuonsach AS CuonTreEm,
           mNL.ngay_muon AS NgayMuonNguoiLon, mTE.ngay_muon AS NgayMuonTreEm
    FROM dbo.Nguoilon nl
    INNER JOIN dbo.DocGia dgNL ON dgNL.ma_DocGia = nl.ma_DocGia
    INNER JOIN dbo.Muon mNL ON mNL.ma_DocGia = nl.ma_DocGia
    INNER JOIN dbo.Treem te ON te.ma_DocGia_nguoilon = nl.ma_DocGia
    INNER JOIN dbo.DocGia dgTE ON dgTE.ma_DocGia = te.ma_DocGia
    INNER JOIN dbo.Muon mTE ON mTE.ma_DocGia = te.ma_DocGia
    ORDER BY nl.ma_DocGia, te.ma_DocGia;
END;
GO

CREATE OR ALTER TRIGGER dbo.tg_delMuon
ON dbo.Muon
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE cs SET tinhtrang = 'yes'
    FROM dbo.Cuonsach cs INNER JOIN deleted d
      ON d.isbn = cs.isbn AND d.ma_cuonsach = cs.ma_cuonsach;
END;
GO

CREATE OR ALTER TRIGGER dbo.tg_insMuon
ON dbo.Muon
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE cs SET tinhtrang = 'no'
    FROM dbo.Cuonsach cs INNER JOIN inserted i
      ON i.isbn = cs.isbn AND i.ma_cuonsach = cs.ma_cuonsach;
END;
GO

CREATE OR ALTER TRIGGER dbo.tg_updCuonSach
ON dbo.Cuonsach
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF UPDATE(tinhtrang)
    BEGIN
        ;WITH Affected AS
        (
            SELECT isbn FROM inserted
            UNION
            SELECT isbn FROM deleted
        )
        UPDATE ds
        SET trangthai = CASE WHEN EXISTS
            (SELECT 1 FROM dbo.Cuonsach cs WHERE cs.isbn = ds.isbn AND cs.tinhtrang = 'yes') THEN 'yes' ELSE 'no' END
        FROM dbo.Dausach ds INNER JOIN Affected a ON a.isbn = ds.isbn;
    END;
END;
GO

CREATE OR ALTER TRIGGER dbo.tg_InfThongBao
ON dbo.Tuasach
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM inserted)
       AND (NOT EXISTS (SELECT 1 FROM deleted) OR UPDATE(tuasach) OR UPDATE(tacgia))
        PRINT N'Đã thêm mới tựa sách';
END;
GO
