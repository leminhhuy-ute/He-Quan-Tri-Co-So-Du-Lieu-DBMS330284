/*
   CUOI KY CSDL - BAI 9
   CSDL quan ly sua chua va bao tri xe cua ga-ra.
*/

IF DB_ID(N'CuoiKy_Gara') IS NULL
    EXEC(N'CREATE DATABASE CuoiKy_Gara');
GO

USE CuoiKy_Gara;
GO

IF OBJECT_ID(N'dbo.THO', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.THO
    (
        MaTho CHAR(4) NOT NULL CONSTRAINT PK_THO PRIMARY KEY,
        TenTho NVARCHAR(100) NOT NULL,
        Nhom NVARCHAR(50) NOT NULL,
        NhomTruong CHAR(4) NOT NULL,
        CONSTRAINT UQ_THO_Nhom_MaTho UNIQUE (Nhom, MaTho),
        CONSTRAINT FK_THO_NhomTruong FOREIGN KEY (Nhom, NhomTruong) REFERENCES dbo.THO(Nhom, MaTho)
    );
END;
GO

IF OBJECT_ID(N'dbo.CONGVIEC', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CONGVIEC
    (
        MaCV CHAR(4) NOT NULL CONSTRAINT PK_CONGVIEC PRIMARY KEY,
        NoiDungCV NVARCHAR(200) NOT NULL
    );
END;
GO

IF OBJECT_ID(N'dbo.KHACHHANG', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.KHACHHANG
    (
        MaKH CHAR(5) NOT NULL CONSTRAINT PK_KHACHHANG PRIMARY KEY,
        TenKH NVARCHAR(120) NOT NULL,
        DiaChi NVARCHAR(200) NULL,
        DienThoai VARCHAR(20) NULL
    );
END;
GO

IF OBJECT_ID(N'dbo.HOPDONG', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.HOPDONG
    (
        SoHD CHAR(5) NOT NULL CONSTRAINT PK_HOPDONG PRIMARY KEY,
        NgayHD DATE NOT NULL,
        MaKH CHAR(5) NOT NULL,
        SoXe VARCHAR(20) NOT NULL,
        TriGiaHD DECIMAL(14,2) NOT NULL,
        NgayGiaoDK DATE NOT NULL,
        NgayNgThu DATE NULL,
        CONSTRAINT FK_HOPDONG_KhachHang FOREIGN KEY (MaKH) REFERENCES dbo.KHACHHANG(MaKH),
        CONSTRAINT UQ_HOPDONG_KhachXeNgay UNIQUE (MaKH, SoXe, NgayHD),
        CONSTRAINT CK_HOPDONG_TriGia CHECK (TriGiaHD >= 0),
        CONSTRAINT CK_HOPDONG_Ngay CHECK (NgayGiaoDK >= NgayHD AND (NgayNgThu IS NULL OR NgayNgThu >= NgayHD))
    );
END;
GO

IF OBJECT_ID(N'dbo.CHITIET_HD', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CHITIET_HD
    (
        SoHD CHAR(5) NOT NULL,
        MaCV CHAR(4) NOT NULL,
        TriGiaCV DECIMAL(14,2) NOT NULL,
        MaTho CHAR(4) NOT NULL,
        KhoanTHo DECIMAL(14,2) NOT NULL,
        CONSTRAINT PK_CHITIET_HD PRIMARY KEY (SoHD, MaCV),
        CONSTRAINT FK_CHITIET_HOPDONG FOREIGN KEY (SoHD) REFERENCES dbo.HOPDONG(SoHD),
        CONSTRAINT FK_CHITIET_CONGVIEC FOREIGN KEY (MaCV) REFERENCES dbo.CONGVIEC(MaCV),
        CONSTRAINT FK_CHITIET_THO FOREIGN KEY (MaTho) REFERENCES dbo.THO(MaTho),
        CONSTRAINT CK_CHITIET_Tien CHECK (TriGiaCV >= 0 AND KhoanTHo >= 0 AND KhoanTHo <= TriGiaCV)
    );
END;
GO

IF OBJECT_ID(N'dbo.PHIEUTHU', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PHIEUTHU
    (
        SoPT CHAR(5) NOT NULL CONSTRAINT PK_PHIEUTHU PRIMARY KEY,
        NgaylapPT DATE NOT NULL,
        SoHD CHAR(5) NOT NULL,
        MaKH CHAR(5) NOT NULL,
        HoTen NVARCHAR(120) NOT NULL,
        SoTienThu DECIMAL(14,2) NOT NULL,
        CONSTRAINT FK_PHIEUTHU_HOPDONG FOREIGN KEY (SoHD) REFERENCES dbo.HOPDONG(SoHD),
        CONSTRAINT FK_PHIEUTHU_KHACHHANG FOREIGN KEY (MaKH) REFERENCES dbo.KHACHHANG(MaKH),
        CONSTRAINT CK_PHIEUTHU_Tien CHECK (SoTienThu > 0)
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.THO)
BEGIN
    INSERT dbo.THO (MaTho, TenTho, Nhom, NhomTruong)
    VALUES ('T001', N'Nguyễn Văn Sơn', N'Động cơ', 'T001'),
           ('T003', N'Lê Minh Đức', N'Gầm - máy', 'T003'),
           ('T005', N'Phạm Quốc Bảo', N'Điện ô tô', 'T005');

    INSERT dbo.THO (MaTho, TenTho, Nhom, NhomTruong)
    VALUES ('T002', N'Trần Hoàng Nam', N'Động cơ', 'T001'),
           ('T004', N'Võ Thanh Tùng', N'Gầm - máy', 'T003');

    INSERT dbo.CONGVIEC (MaCV, NoiDungCV)
    VALUES ('CV01', N'Thay dầu và lọc dầu'),
           ('CV02', N'Kiểm tra hệ thống phanh'),
           ('CV03', N'Sửa hệ thống điện'),
           ('CV04', N'Cân chỉnh động cơ'),
           ('CV05', N'Thay lốp và cân bằng bánh');

    INSERT dbo.KHACHHANG (MaKH, TenKH, DiaChi, DienThoai)
    VALUES ('KH001', N'Công ty Minh Long', N'TP.HCM', '0909000001'),
           ('KH002', N'Nguyễn Thị Hạnh', N'Đồng Nai', '0909000002'),
           ('KH003', N'Trần Văn Phúc', N'Bình Dương', '0909000003');

    INSERT dbo.HOPDONG (SoHD, NgayHD, MaKH, SoXe, TriGiaHD, NgayGiaoDK, NgayNgThu)
    VALUES
        ('HD001', DATEADD(DAY, -60, CONVERT(date, GETDATE())), 'KH001', '51A-111.11', 10000000, DATEADD(DAY, -40, CONVERT(date, GETDATE())), DATEADD(DAY, -35, CONVERT(date, GETDATE()))),
        ('HD002', DATEADD(DAY, -50, CONVERT(date, GETDATE())), 'KH002', '60B-222.22', 6000000, DATEADD(DAY, -30, CONVERT(date, GETDATE())), DATEADD(DAY, -25, CONVERT(date, GETDATE()))),
        ('HD003', DATEADD(DAY, -10, CONVERT(date, GETDATE())), 'KH003', '61C-333.33', 7000000, DATEADD(DAY, -2, CONVERT(date, GETDATE())), NULL),
        ('HD004', CONVERT(date, GETDATE()), 'KH001', '51A-444.44', 5000000, DATEADD(DAY, 15, CONVERT(date, GETDATE())), NULL);

    INSERT dbo.CHITIET_HD (SoHD, MaCV, TriGiaCV, MaTho, KhoanTHo)
    VALUES
        ('HD001', 'CV01', 4000000, 'T001', 2500000),
        ('HD001', 'CV02', 3000000, 'T002', 1800000),
        ('HD001', 'CV03', 3000000, 'T002', 2000000),
        ('HD002', 'CV01', 2500000, 'T003', 1500000),
        ('HD002', 'CV04', 3500000, 'T004', 2200000),
        ('HD003', 'CV02', 3000000, 'T002', 1800000),
        ('HD003', 'CV04', 4000000, 'T002', 2400000),
        ('HD004', 'CV05', 5000000, 'T004', 3000000);

    INSERT dbo.PHIEUTHU (SoPT, NgaylapPT, SoHD, MaKH, HoTen, SoTienThu)
    VALUES
        ('PT001', DATEADD(DAY, -45, CONVERT(date, GETDATE())), 'HD001', 'KH001', N'Nguyễn Minh Long', 3000000),
        ('PT002', DATEADD(DAY, -38, CONVERT(date, GETDATE())), 'HD001', 'KH001', N'Nguyễn Minh Long', 2000000),
        ('PT003', DATEADD(DAY, -28, CONVERT(date, GETDATE())), 'HD002', 'KH002', N'Nguyễn Thị Hạnh', 6000000);
END;
GO

CREATE OR ALTER FUNCTION dbo.fn_ThoChuaThamGiaHopDong ()
RETURNS TABLE
AS
RETURN
(
    SELECT t.MaTho, t.TenTho, t.Nhom, t.NhomTruong
    FROM dbo.THO t
    WHERE NOT EXISTS (SELECT 1 FROM dbo.CHITIET_HD c WHERE c.MaTho = t.MaTho)
);
GO

CREATE OR ALTER FUNCTION dbo.fn_HopDongDaThanhLyChuaThanhToan ()
RETURNS TABLE
AS
RETURN
(
    SELECT hd.SoHD, hd.NgayHD, hd.MaKH, kh.TenKH, hd.TriGiaHD,
           ISNULL(pt.DaThu, 0) AS DaThu,
           hd.TriGiaHD - ISNULL(pt.DaThu, 0) AS ConNo
    FROM dbo.HOPDONG hd
    INNER JOIN dbo.KHACHHANG kh ON kh.MaKH = hd.MaKH
    OUTER APPLY
    (
        SELECT SUM(SoTienThu) AS DaThu FROM dbo.PHIEUTHU p WHERE p.SoHD = hd.SoHD
    ) pt
    WHERE hd.NgayNgThu IS NOT NULL AND ISNULL(pt.DaThu, 0) < hd.TriGiaHD
);
GO

CREATE OR ALTER FUNCTION dbo.fn_HopDongCanHoanTatTruocNgay (@Ngay DATE)
RETURNS TABLE
AS
RETURN
(
    SELECT hd.SoHD, hd.MaKH, kh.TenKH, hd.SoXe, hd.NgayGiaoDK, hd.TriGiaHD
    FROM dbo.HOPDONG hd INNER JOIN dbo.KHACHHANG kh ON kh.MaKH = hd.MaKH
    WHERE hd.NgayNgThu IS NULL AND hd.NgayGiaoDK < @Ngay
);
GO

CREATE OR ALTER FUNCTION dbo.fn_ThoThucHienNhieuNhat ()
RETURNS TABLE
AS
RETURN
(
    WITH S AS
    (
        SELECT t.MaTho, t.TenTho, COUNT(c.MaCV) AS SoLuongCongViec
        FROM dbo.THO t LEFT JOIN dbo.CHITIET_HD c ON c.MaTho = t.MaTho
        GROUP BY t.MaTho, t.TenTho
    )
    SELECT MaTho, TenTho, SoLuongCongViec
    FROM S
    WHERE SoLuongCongViec = (SELECT MAX(SoLuongCongViec) FROM S)
);
GO

CREATE OR ALTER FUNCTION dbo.fn_ThoTongTriGiaCaoNhat ()
RETURNS TABLE
AS
RETURN
(
    WITH S AS
    (
        SELECT t.MaTho, t.TenTho, ISNULL(SUM(c.TriGiaCV), 0) AS TongTriGiaCongViec
        FROM dbo.THO t LEFT JOIN dbo.CHITIET_HD c ON c.MaTho = t.MaTho
        GROUP BY t.MaTho, t.TenTho
    )
    SELECT MaTho, TenTho, TongTriGiaCongViec
    FROM S
    WHERE TongTriGiaCongViec = (SELECT MAX(TongTriGiaCongViec) FROM S)
);
GO
