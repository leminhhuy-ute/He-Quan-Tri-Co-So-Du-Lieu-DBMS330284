using Microsoft.Data.SqlClient;

namespace CuoiKyWinForms;

internal static class Db
{
    // Instance mặc định tương ứng với nơi bộ script hiện tại đã tạo các CSDL CuoiKy_*.
    public const string DefaultServer = @"(localdb)\MSSQLLocalDB";
    public const string AlternateLocalDbServer = @"(localdb)\BTWinFormsLocalDB";
    public const string LibraryDatabase = "CuoiKy_ThuVien";
    public const string ProjectDatabase = "CuoiKy_DeAn";
    public const string GarageDatabase = "CuoiKy_Gara";
    public const string SchoolDatabase = "CuoiKy_TruongHoc";

    public static string DatabaseDisplayName(string database) => database switch
    {
        LibraryDatabase => "CSDL Thư viện",
        ProjectDatabase => "CSDL Đề án",
        GarageDatabase => "CSDL Gara",
        SchoolDatabase => "CSDL Trường học",
        _ => database
    };

    public static SqlConnection CreateConnection(string server, string database)
    {
        var builder = new SqlConnectionStringBuilder
        {
            DataSource = string.IsNullOrWhiteSpace(server) ? DefaultServer : server.Trim(),
            InitialCatalog = database,
            IntegratedSecurity = true,
            TrustServerCertificate = true,
            ConnectTimeout = 5
        };
        return new SqlConnection(builder.ConnectionString);
    }
}
