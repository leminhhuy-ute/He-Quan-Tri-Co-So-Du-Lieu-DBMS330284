using System.Data;
using System.Diagnostics;
using Microsoft.Data.SqlClient;

namespace CuoiKyWinForms;

public sealed class MainForm : Form
{
    private readonly TextBox _serverTextBox = new();
    private readonly Label _statusLabel = new();

    public MainForm()
    {
        Text = "Bài tập lớn cuối kỳ - CSDL";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(900, 650);
        Size = new Size(1250, 800);
        WindowState = FormWindowState.Maximized;
        MaximizeBox = true;
        Font = new Font("Segoe UI", 10F);
        BackColor = Color.FromArgb(246, 248, 251);
        BuildLayout();
    }

    private void BuildLayout()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            Padding = new Padding(22),
            BackColor = BackColor
        };
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        root.Controls.Add(new Label
        {
            Text = "BÀI TẬP LỚN CUỐI KỲ - CƠ SỞ DỮ LIỆU",
            Dock = DockStyle.Fill,
            AutoSize = true,
            Font = new Font("Segoe UI", 20F, FontStyle.Bold),
            ForeColor = Color.FromArgb(29, 63, 111),
            Padding = new Padding(0, 0, 0, 12)
        }, 0, 0);

        root.Controls.Add(BuildConnectionBar(), 0, 1);
        root.Controls.Add(BuildExerciseGrid(), 0, 2);
    }

    private Control BuildConnectionBar()
    {
        var connectionBar = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            Padding = new Padding(0, 0, 0, 16)
        };
        connectionBar.Controls.Add(new Label
        {
            Text = "SQL Server:",
            AutoSize = true,
            Padding = new Padding(0, 9, 8, 0)
        });

        _serverTextBox.Text = Db.DefaultServer;
        _serverTextBox.Width = 330;
        _serverTextBox.Margin = new Padding(0, 4, 8, 0);
        connectionBar.Controls.Add(_serverTextBox);

        connectionBar.Controls.Add(MakeButton("Kết nối Thư viện", async (_, _) => await TestConnectionAsync(Db.LibraryDatabase), 145));
        connectionBar.Controls.Add(MakeButton("Kết nối Đề án", async (_, _) => await TestConnectionAsync(Db.ProjectDatabase), 130));
        connectionBar.Controls.Add(MakeButton("Kết nối Gara", async (_, _) => await TestConnectionAsync(Db.GarageDatabase), 115));
        connectionBar.Controls.Add(MakeButton("Kết nối Trường", async (_, _) => await TestConnectionAsync(Db.SchoolDatabase), 125));

        _statusLabel.Text = "Chạy 4 script SQL trong thư mục database trước khi kết nối.";
        _statusLabel.AutoSize = true;
        _statusLabel.MaximumSize = new Size(520, 0);
        _statusLabel.MinimumSize = new Size(360, 0);
        _statusLabel.ForeColor = Color.FromArgb(80, 88, 101);
        _statusLabel.Padding = new Padding(10, 8, 0, 0);
        connectionBar.Controls.Add(_statusLabel);
        return connectionBar;
    }

    private Control BuildExerciseGrid()
    {
        var group = new GroupBox
        {
            Text = "Chọn bài tập",
            Dock = DockStyle.Fill,
            ForeColor = Color.FromArgb(29, 63, 111),
            Padding = new Padding(14, 28, 14, 14)
        };
        var grid = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 5,
            Padding = new Padding(2)
        };
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        for (var row = 0; row < 5; row++)
            grid.RowStyles.Add(new RowStyle(SizeType.Percent, 20));

        AddExerciseButton(grid, 0, 0, "Bài 1\nStored procedure giải PT bậc 1", OpenExercise1);
        AddExerciseButton(grid, 1, 0, "Bài 2\nFunction giải PT bậc 2", OpenExercise2);
        AddExerciseButton(grid, 0, 1, "Bài 3\nThông tin đầu sách theo ISBN", OpenExercise3);
        AddExerciseButton(grid, 1, 1, "Bài 4\nFunction tính tuổi", OpenExercise4);
        AddExerciseButton(grid, 0, 2, "Bài 5\nStored procedure CSDL Thư viện", OpenExercise5);
        AddExerciseButton(grid, 1, 2, "Bài 6\nTrigger CSDL Thư viện", OpenExercise6);
        AddExerciseButton(grid, 0, 3, "Bài 7\nFunction CSDL Đề án", OpenExercise7);
        AddExerciseButton(grid, 1, 3, "Bài 8\nTruy vấn nhóm CSDL Đề án", OpenExercise8);
        AddExerciseButton(grid, 0, 4, "Bài 9\nFunction CSDL Gara", OpenExercise9);
        AddExerciseButton(grid, 1, 4, "Bài 10\nFunction và ràng buộc thi", OpenExercise10);

        group.Controls.Add(grid);
        return group;
    }

    private void OpenExercise1()
    {
        OpenQuery(this, "Bài 1 - Stored procedure giải phương trình bậc 1", Db.LibraryDatabase,
            "EXEC dbo.sp_GiaiPTBac1 @a = @a, @b = @b;",
            "Câu hỏi: Viết stored procedure giải ax + b = 0 với a, b bất kỳ.",
            new QueryParameter("@a", SqlDbType.Decimal, "Hệ số a", "2", 0, 18, 6),
            new QueryParameter("@b", SqlDbType.Decimal, "Hệ số b", "-6", 0, 18, 6));
    }

    private void OpenExercise2()
    {
        OpenQuery(this, "Bài 2 - Function giải phương trình bậc 2", Db.LibraryDatabase,
            "SELECT dbo.fn_GiaiPTBac2(@a, @b, @c) AS KetQua;",
            "Câu hỏi: Viết hàm trả về kết quả giải ax² + bx + c = 0.",
            new QueryParameter("@a", SqlDbType.Decimal, "Hệ số a", "1", 0, 18, 6),
            new QueryParameter("@b", SqlDbType.Decimal, "Hệ số b", "-3", 0, 18, 6),
            new QueryParameter("@c", SqlDbType.Decimal, "Hệ số c", "2", 0, 18, 6));
    }

    private void OpenExercise3()
    {
        OpenQuery(this, "Bài 3 - Thông tin đầu sách", Db.LibraryDatabase,
            "EXEC dbo.sp_ThongtinDausach @ISBN = @ISBN;",
            "Câu hỏi: Liệt kê thông tin đầu sách, tựa sách và số lượng cuốn hiện chưa được mượn theo ISBN.",
            new QueryParameter("@ISBN", SqlDbType.VarChar, "ISBN", "ISBN001", 20));
    }

    private void OpenExercise4()
    {
        OpenQuery(this, "Bài 4 - Function tính tuổi", Db.LibraryDatabase,
            "SELECT @NamSinh AS NamSinh, dbo.fn_TinhTuoi(@NamSinh) AS Tuoi;",
            "Câu hỏi: Viết hàm tính tuổi của người có năm sinh truyền vào.",
            new QueryParameter("@NamSinh", SqlDbType.Int, "Năm sinh", "2000"));
    }

    private void OpenExercise5()
    {
        using var menu = new ExerciseMenuForm(
            "Bài 5 - Stored procedure CSDL Thư viện",
            "Chọn một thủ tục. Bài 5 gồm kiểm tra loại độc giả, đầu sách và các nhóm độc giả đang mượn.",
            new ExerciseOption("5a. sp_ThongtinDocGia", "Thông tin độc giả người lớn hoặc trẻ em theo mã.", owner => OpenQuery(owner,
                "Bài 5a - Thông tin độc giả", Db.LibraryDatabase,
                "EXEC dbo.sp_ThongtinDocGia @MaDocGia = @MaDocGia;",
                "[1] Kiểm tra loại độc giả; [2] trả về thông tin người lớn hoặc trẻ em tương ứng.",
                new QueryParameter("@MaDocGia", SqlDbType.Int, "Mã độc giả (1 hoặc 3)", "1"))),
            new ExerciseOption("5b. sp_ThongtinDausach", "Thông tin đầu sách và số lượng chưa mượn.", owner => OpenQuery(owner,
                "Bài 5b - Thông tin đầu sách", Db.LibraryDatabase,
                "EXEC dbo.sp_ThongtinDausach @ISBN = @ISBN;",
                "Liệt kê thông tin tựa sách, đầu sách và các cuốn có tình trạng yes.",
                new QueryParameter("@ISBN", SqlDbType.VarChar, "ISBN", "ISBN001", 20))),
            new ExerciseOption("5c. sp_ThongtinNguoilonDangmuon", "Tất cả độc giả người lớn đang mượn.", owner => OpenQuery(owner,
                "Bài 5c - Người lớn đang mượn", Db.LibraryDatabase,
                "EXEC dbo.sp_ThongtinNguoilonDangmuon;",
                "Liệt kê thông tin độc giả người lớn và cuốn sách đang được mượn.")),
            new ExerciseOption("5d. sp_ThongtinNguoilonQuahan", "Người lớn mượn quá hạn trên 14 ngày.", owner => OpenQuery(owner,
                "Bài 5d - Người lớn quá hạn", Db.LibraryDatabase,
                "EXEC dbo.sp_ThongtinNguoilonQuahan;",
                "Liệt kê độc giả người lớn có ngày hết hạn cách hiện tại hơn 14 ngày.")),
            new ExerciseOption("5e. sp_DocGiaCoTreEmMuon", "Người lớn và trẻ em được bảo lãnh cùng đang mượn.", owner => OpenQuery(owner,
                "Bài 5e - Người lớn có trẻ em cùng mượn", Db.LibraryDatabase,
                "EXEC dbo.sp_DocGiaCoTreEmMuon;",
                "Liệt kê người lớn và trẻ em do người lớn đó bảo lãnh khi cả hai đều đang mượn.")));
        menu.ShowDialog(this);
    }

    private void OpenExercise6()
    {
        using var menu = new ExerciseMenuForm(
            "Bài 6 - Kiểm tra Trigger CSDL Thư viện",
            "Mỗi nút chạy trong BEGIN TRAN và ROLLBACK để quan sát kết quả trigger mà không đổi dữ liệu thật.",
            new ExerciseOption("6.1. tg_insMuon", "Thêm lượt mượn -> tình trạng cuốn sách thành no.", owner => OpenQuery(owner,
                "Bài 6.1 - Test tg_insMuon", Db.LibraryDatabase, TriggerInsertSql,
                "Trigger sau INSERT trên Muon cập nhật Cuonsach.tinhtrang = no và cập nhật đầu sách.")),
            new ExerciseOption("6.2. tg_delMuon", "Xóa lượt mượn -> tình trạng cuốn sách thành yes.", owner => OpenQuery(owner,
                "Bài 6.2 - Test tg_delMuon", Db.LibraryDatabase, TriggerDeleteSql,
                "Trigger sau DELETE trên Muon cập nhật Cuonsach.tinhtrang = yes.")),
            new ExerciseOption("6.3. tg_updCuonSach", "Sửa tình trạng cuốn -> cập nhật trạng thái đầu sách.", owner => OpenQuery(owner,
                "Bài 6.3 - Test tg_updCuonSach", Db.LibraryDatabase, TriggerUpdateSql,
                "Trigger sau UPDATE Cuonsach tính lại Dausach.trangthai theo các cuốn còn available.")),
            new ExerciseOption("6.4. tg_InfThongBao", "Thêm tựa sách -> in thông báo tiếng Việt.", owner => OpenQuery(owner,
                "Bài 6.4 - Test tg_InfThongBao", Db.LibraryDatabase, TriggerNotifySql,
                "Trigger sau INSERT/UPDATE Tuasach PRINT thông báo 'Đã thêm mới tựa sách'.")));
        menu.ShowDialog(this);
    }

    private void OpenExercise7()
    {
        using var menu = new ExerciseMenuForm(
            "Bài 7 - Function CSDL Đề án",
            "Các function scalar, Inline TVF và Multistatement TVF theo yêu cầu đề.",
            new ExerciseOption("7.1. Lương trung bình phòng ban", "Truyền MaPB.", owner => OpenQuery(owner,
                "Bài 7.1 - Lương trung bình phòng ban", Db.ProjectDatabase,
                "SELECT @MaPB AS MaPB, dbo.fn_LuongTBPhongBan(@MaPB) AS LuongTB;",
                "Tính lương trung bình của một phòng ban tùy ý.",
                new QueryParameter("@MaPB", SqlDbType.Char, "Mã phòng ban", "P001", 4))),
            new ExerciseOption("7.2. Lương nhân viên theo dự án", "Truyền MaNV và MaDA.", owner => OpenQuery(owner,
                "Bài 7.2 - Lương theo dự án", Db.ProjectDatabase,
                "SELECT @MaNV AS MaNV, @MaDA AS MaDA, dbo.fn_TongLuongNhanVienTheoDuAn(@MaNV, @MaDA) AS TongLuong;",
                "Tính tổng tiền lương nhận được theo số giờ tham gia dự án.",
                new QueryParameter("@MaNV", SqlDbType.Char, "Mã nhân viên", "NV0000001", 9),
                new QueryParameter("@MaDA", SqlDbType.Char, "Mã dự án", "DA02", 4))),
            new ExerciseOption("7.3. Lương trung bình các phòng ban", "Trung bình của các mức trung bình phòng ban.", owner => OpenQuery(owner,
                "Bài 7.3 - Lương trung bình các phòng", Db.ProjectDatabase,
                "SELECT dbo.fn_LuongTBAllPhongBan() AS LuongTBAllPhongBan;",
                "Tính mức lương trung bình của các phòng ban.")),
            new ExerciseOption("7.4. Tiền thưởng theo Time_Total", "Kiểm tra đủ các mốc 30, 60, 100 và 150 giờ.", owner => OpenQuery(owner,
                "Bài 7.4 - Tiền thưởng theo số giờ", Db.ProjectDatabase,
                "SELECT @Time_Total AS Time_Total, dbo.fn_TienThuongTheoGio(@Time_Total) AS TienThuong;",
                "Tính tiền thưởng theo bốn khoảng Time_Total trong đề.",
                new QueryParameter("@Time_Total", SqlDbType.Decimal, "Tổng số giờ", "75", 0, 10, 2))),
            new ExerciseOption("7.5. Tổng số dự án theo phòng ban", "Đếm dự án theo MaPB.", owner => OpenQuery(owner,
                "Bài 7.5 - Tổng số dự án theo phòng", Db.ProjectDatabase,
                "SELECT MaPB, TenPB, dbo.fn_TongDuAnTheoPhongBan(MaPB) AS TongDuAn FROM dbo.PhongBan ORDER BY MaPB;",
                "Trả về tổng số dự án của từng phòng ban.")),
            new ExerciseOption("7.6. Hai loại Table-Valued Function", "So sánh Inline TVF và Multistatement TVF.", owner => OpenQuery(owner,
                "Bài 7.6 - Inline TVF và MSTVF", Db.ProjectDatabase,
                "SELECT N'Inline TVF' AS Cach, MaNV, HoTen, NgaySinh, NguoiThan, TongLuongTB FROM dbo.fn_ThongTinNhanVien_ITVF() " +
                "UNION ALL SELECT N'Multistatement TVF', MaNV, HoTen, NgaySinh, NguoiThan, TongLuongTB FROM dbo.fn_ThongTinNhanVien_MSTVF() " +
                "ORDER BY Cach, MaNV;",
                "Hai hàm trả về bảng có cùng thông tin: MaNV, HoTen, NgaySinh, NguoiThan, TongLuongTB.")));
        menu.ShowDialog(this);
    }

    private void OpenExercise8()
    {
        using var menu = new ExerciseMenuForm(
            "Bài 8 - Truy vấn nhóm CSDL Đề án",
            "Các hàm trả về bảng dùng GROUP BY, HAVING và điều kiện phòng ban.",
            new ExerciseOption("8.1. Dự án có hơn 2 nhân viên", "Mã dự án, tên dự án và số lượng nhân viên.", owner => OpenQuery(owner,
                "Bài 8.1 - Dự án nhiều nhân viên", Db.ProjectDatabase,
                "SELECT * FROM dbo.fn_DuAnNhieuHonHaiNhanVien() ORDER BY MaDA;",
                "Với mỗi dự án có nhiều hơn 2 nhân viên tham gia.")),
            new ExerciseOption("8.2. Phòng có hơn 2 nhân viên", "Đếm nhân viên có lương > 25000.", owner => OpenQuery(owner,
                "Bài 8.2 - Phòng nhiều nhân viên lương cao", Db.ProjectDatabase,
                "SELECT * FROM dbo.fn_PhongNhieuHonHaiNhanVienLuongCao() ORDER BY MaPB;",
                "Với mỗi phòng có nhiều hơn 2 nhân viên, đếm nhân viên có lương lớn hơn 25000.")),
            new ExerciseOption("8.3. Phòng lương TB > 30000", "Mã phòng, tên phòng, số lượng nhân viên.", owner => OpenQuery(owner,
                "Bài 8.3 - Phòng lương trung bình cao", Db.ProjectDatabase,
                "SELECT * FROM dbo.fn_PhongLuongTBCao() ORDER BY MaPB;",
                "Với mỗi phòng có lương trung bình lớn hơn 30000.")),
            new ExerciseOption("8.4. Phòng lương TB > 30000 - nam", "Đếm số nhân viên nam.", owner => OpenQuery(owner,
                "Bài 8.4 - Phòng có nhân viên nam", Db.ProjectDatabase,
                "SELECT * FROM dbo.fn_PhongLuongTBCao_Nam() ORDER BY MaPB;",
                "Với mỗi phòng có lương trung bình lớn hơn 30000, đếm nhân viên nam.")),
            new ExerciseOption("8.5. Nhân viên phòng 5 theo dự án", "Đếm nhân viên P005 tham gia từng dự án.", owner => OpenQuery(owner,
                "Bài 8.5 - Nhân viên phòng 5", Db.ProjectDatabase,
                "SELECT * FROM dbo.fn_DuAnVaNhanVienPhong5() ORDER BY MaDA;",
                "Với mỗi dự án, trả về số lượng nhân viên thuộc phòng số 5 tham gia.")));
        menu.ShowDialog(this);
    }

    private void OpenExercise9()
    {
        using var menu = new ExerciseMenuForm(
            "Bài 9 - Function CSDL Gara",
            "Các hàm phân tích thợ, hợp đồng, thanh toán và hạn giao xe.",
            new ExerciseOption("9.1. Thợ chưa tham gia hợp đồng", "Danh sách người thợ không xuất hiện trong chi tiết hợp đồng.", owner => OpenQuery(owner,
                "Bài 9.1 - Thợ chưa tham gia", Db.GarageDatabase,
                "SELECT * FROM dbo.fn_ThoChuaThamGiaHopDong() ORDER BY MaTho;",
                "Cho biết danh sách các người thợ hiện không tham gia hợp đồng sửa chữa nào.")),
            new ExerciseOption("9.2. Đã thanh lý nhưng còn nợ", "Hợp đồng đã nghiệm thu nhưng chưa thanh toán đủ.", owner => OpenQuery(owner,
                "Bài 9.2 - Hợp đồng còn nợ", Db.GarageDatabase,
                "SELECT * FROM dbo.fn_HopDongDaThanhLyChuaThanhToan() ORDER BY SoHD;",
                "Cho biết các hợp đồng đã thanh lý và số tiền còn phải thu.")),
            new ExerciseOption("9.3. Cần hoàn tất trước ngày", "Nhập ngày cần kiểm tra.", owner => OpenQuery(owner,
                "Bài 9.3 - Hợp đồng cần hoàn tất", Db.GarageDatabase,
                "SELECT * FROM dbo.fn_HopDongCanHoanTatTruocNgay(@Ngay) ORDER BY NgayGiaoDK;",
                "Cho biết các hợp đồng chưa nghiệm thu nhưng có ngày giao dự kiến trước ngày nhập.",
                new QueryParameter("@Ngay", SqlDbType.Date, "Ngày kiểm tra", DateTime.Today.ToString("yyyy-MM-dd")))),
            new ExerciseOption("9.4. Người thợ làm nhiều việc nhất", "Có xử lý đồng hạng.", owner => OpenQuery(owner,
                "Bài 9.4 - Thợ làm nhiều việc nhất", Db.GarageDatabase,
                "SELECT * FROM dbo.fn_ThoThucHienNhieuNhat();",
                "Cho biết người thợ thực hiện nhiều công việc nhất.")),
            new ExerciseOption("9.5. Người thợ có trị giá cao nhất", "Có xử lý đồng hạng.", owner => OpenQuery(owner,
                "Bài 9.5 - Thợ có trị giá cao nhất", Db.GarageDatabase,
                "SELECT * FROM dbo.fn_ThoTongTriGiaCaoNhat();",
                "Cho biết người thợ có tổng trị giá công việc được giao cao nhất.")));
        menu.ShowDialog(this);
    }

    private void OpenExercise10()
    {
        using var menu = new ExerciseMenuForm(
            "Bài 10 - Function và ràng buộc CSDL Trường học",
            "Các function phục vụ câu hỏi 10.2; trigger đã cài để bảo vệ hai ràng buộc 10.1.",
            new ExerciseOption("10.2a. Giáo viên dạy môn từ 45 tiết", "Danh sách giáo viên và môn học.", owner => OpenQuery(owner,
                "Bài 10.2a - Giáo viên dạy môn >=45 tiết", Db.SchoolDatabase,
                "SELECT * FROM dbo.fn_GiaoVienDayMon45() ORDER BY MAGV;",
                "Liệt kê giáo viên dạy môn có số tiết từ 45 trở lên.")),
            new ExerciseOption("10.2b. Giáo viên gác thi học kỳ 1", "Danh sách giáo viên có phân công HK1.", owner => OpenQuery(owner,
                "Bài 10.2b - Giáo viên gác thi HK1", Db.SchoolDatabase,
                "SELECT * FROM dbo.fn_GiaoVienGacThiHK1() ORDER BY MAGV;",
                "Liệt kê giáo viên được phân công gác thi trong học kỳ 1.")),
            new ExerciseOption("10.2c. Giáo viên không gác thi HK1", "Danh sách giáo viên không có phân công HK1.", owner => OpenQuery(owner,
                "Bài 10.2c - Giáo viên không gác thi HK1", Db.SchoolDatabase,
                "SELECT * FROM dbo.fn_GiaoVienKhongGacThiHK1() ORDER BY MAGV;",
                "Liệt kê giáo viên không được phân công gác thi trong học kỳ 1.")),
            new ExerciseOption("10.2d. Lịch thi môn Văn", "TENMH = VĂN HỌC.", owner => OpenQuery(owner,
                "Bài 10.2d - Lịch thi Văn học", Db.SchoolDatabase,
                "SELECT * FROM dbo.fn_LichThiMonVan() ORDER BY HKY, NGAY, GIO;",
                "Cho biết lịch thi môn có tên VĂN HỌC.")),
            new ExerciseOption("10.2e. Chủ nhiệm Văn gác thi", "Các buổi gác thi của giáo viên chủ nhiệm môn Văn.", owner => OpenQuery(owner,
                "Bài 10.2e - Chủ nhiệm Văn coi thi", Db.SchoolDatabase,
                "SELECT * FROM dbo.fn_GacThiChuNhiemVan() ORDER BY HKY, NGAY, GIO;",
                "Cho biết các buổi gác thi của giáo viên chủ nhiệm môn VĂN HỌC.")),
            new ExerciseOption("Kiểm tra ràng buộc 10.1", "Giao dịch thử, bắt lỗi và rollback.", owner => OpenQuery(owner,
                "Bài 10.1 - Test ràng buộc thi", Db.SchoolDatabase, SchoolConstraintTestSql,
                "Thử gán giáo viên coi chính môn mình dạy; trigger phải từ chối thao tác.")));
        menu.ShowDialog(this);
    }

    private void OpenQuery(IWin32Window owner, string title, string database, string sql, string description, params QueryParameter[] parameters)
    {
        using var form = new QueryForm(title, _serverTextBox.Text, database, sql, description, parameters);
        form.ShowDialog(owner);
    }

    private async Task TestConnectionAsync(string database)
    {
        var server = _serverTextBox.Text.Trim();
        SetConnectionStatus("Đang kiểm tra kết nối SQL Server...", Color.FromArgb(80, 88, 101));
        UseWaitCursor = true;
        ConnectionAttempt attempt;
        try
        {
            attempt = await Task.Run(() => ConnectDatabase(server, database));
        }
        finally
        {
            UseWaitCursor = false;
        }

        if (attempt.Connected)
        {
            _serverTextBox.Text = attempt.EffectiveServer;
            SetConnectionStatus(attempt.StartedLocalDb
                ? $"Đã khởi động LocalDB và kết nối {Db.DatabaseDisplayName(database)}."
                : $"Đã kết nối {Db.DatabaseDisplayName(database)}.", Color.FromArgb(25, 120, 70));
            return;
        }

        var message = attempt.ServerReachable
            ? $"Đã kết nối SQL Server nhưng {Db.DatabaseDisplayName(database)} chưa tồn tại.\n\nHãy chạy script tương ứng trong thư mục database.\nTên CSDL: {database}.\n\nLỗi: {attempt.Error}"
            : $"Không kết nối được tới SQL Server '{server}'.\n\nKiểm tra LocalDB/SQL Express hoặc nhập đúng instance.\n\nLỗi: {attempt.Error}";
        SetConnectionStatus("Lỗi kết nối - xem hộp thoại chi tiết.", Color.Firebrick);
        MessageBox.Show(this, message, "Không thể kết nối SQL Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    private void SetConnectionStatus(string text, Color color)
    {
        _statusLabel.Text = text;
        _statusLabel.ForeColor = color;
    }

    private static ConnectionAttempt ConnectDatabase(string server, string database)
    {
        if (TryOpenDatabase(server, database, out var error))
            return new ConnectionAttempt(true, false, true, server, string.Empty);

        var startedLocalDb = false;
        if (IsLocalDbServer(server))
        {
            startedLocalDb = TryStartLocalDb(server);
            if (TryOpenDatabaseWithRetry(server, database, 8, 500, out error))
                return new ConnectionAttempt(true, startedLocalDb, true, server, string.Empty);

            if (TryGetLocalDbPipe(server, out var pipeServer)
                && TryOpenDatabase(pipeServer, database, out _))
                return new ConnectionAttempt(true, startedLocalDb, true, pipeServer, string.Empty);
        }

        var serverReachable = TryOpenDatabase(server, "master", out _);
        if (IsLocalDbServer(server))
        {
            foreach (var alternateServer in new[] { Db.DefaultServer, Db.AlternateLocalDbServer }.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                if (string.Equals(alternateServer, server, StringComparison.OrdinalIgnoreCase))
                    continue;

                var alternateStarted = TryStartLocalDb(alternateServer);
                if (TryOpenDatabaseWithRetry(alternateServer, database, 4, 400, out _))
                    return new ConnectionAttempt(true, alternateStarted, true, alternateServer, string.Empty);

                if (TryGetLocalDbPipe(alternateServer, out var alternatePipe)
                    && TryOpenDatabase(alternatePipe, database, out _))
                    return new ConnectionAttempt(true, alternateStarted, true, alternatePipe, string.Empty);
            }
        }

        return new ConnectionAttempt(false, startedLocalDb, serverReachable, server, error);
    }

    private static bool TryOpenDatabaseWithRetry(string server, string database, int attempts, int delayMilliseconds, out string error)
    {
        error = string.Empty;
        for (var attempt = 0; attempt < attempts; attempt++)
        {
            if (TryOpenDatabase(server, database, out error))
                return true;
            if (attempt < attempts - 1)
                Thread.Sleep(delayMilliseconds);
        }
        return false;
    }

    private static bool TryOpenDatabase(string server, string database, out string error)
    {
        try
        {
            using var connection = Db.CreateConnection(server, database);
            connection.Open();
            error = string.Empty;
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message.Trim();
            return false;
        }
    }

    private static bool IsLocalDbServer(string server)
        => server.StartsWith("(localdb)\\", StringComparison.OrdinalIgnoreCase);

    private static bool TryGetLocalDbPipe(string server, out string pipeServer)
    {
        pipeServer = string.Empty;
        const string localDbPrefix = "(localdb)\\";
        if (!IsLocalDbServer(server))
            return false;

        var instance = server[localDbPrefix.Length..].Trim();
        if (instance.Length == 0)
            return false;

        try
        {
            using var process = Process.Start(new ProcessStartInfo
            {
                FileName = "sqllocaldb.exe",
                Arguments = $"info \"{instance}\"",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            });
            if (process is null)
                return false;

            var output = process.StandardOutput.ReadToEnd() + Environment.NewLine + process.StandardError.ReadToEnd();
            process.WaitForExit(8000);
            if (!process.HasExited || process.ExitCode != 0)
                return false;

            const string pipePrefix = @"np:\\.\pipe\";
            foreach (var line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var pipeIndex = line.IndexOf(pipePrefix, StringComparison.OrdinalIgnoreCase);
                if (pipeIndex < 0)
                    continue;

                pipeServer = line[pipeIndex..].Trim();
                return pipeServer.Length > pipePrefix.Length;
            }
        }
        catch
        {
            return false;
        }

        return false;
    }

    private static bool TryStartLocalDb(string server)
    {
        const string prefix = "(localdb)\\";
        if (!IsLocalDbServer(server))
            return false;
        var instance = server[prefix.Length..].Trim();
        if (instance.Length == 0)
            return false;
        try
        {
            if (RunLocalDbCommand($"start \"{instance}\"", 8000))
                return true;
            if (!RunLocalDbCommand($"create \"{instance}\"", 8000))
                return false;
            return RunLocalDbCommand($"start \"{instance}\"", 8000);
        }
        catch
        {
            return false;
        }
    }

    private static bool RunLocalDbCommand(string arguments, int timeoutMilliseconds)
    {
        using var process = Process.Start(new ProcessStartInfo
        {
            FileName = "sqllocaldb.exe",
            Arguments = arguments,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        });
        if (process is null)
            return false;
        var standardOutput = process.StandardOutput.ReadToEnd();
        var standardError = process.StandardError.ReadToEnd();
        process.WaitForExit(timeoutMilliseconds);
        if (!process.HasExited || process.ExitCode != 0)
            return false;
        var output = standardOutput + Environment.NewLine + standardError;
        return !output.Contains("failed", StringComparison.OrdinalIgnoreCase)
            && !output.Contains("doesn't exist", StringComparison.OrdinalIgnoreCase)
            && !output.Contains("does not exist", StringComparison.OrdinalIgnoreCase)
            && !output.Contains("error:", StringComparison.OrdinalIgnoreCase);
    }

    private static void AddExerciseButton(TableLayoutPanel grid, int column, int row, string text, Action click)
    {
        var button = MakeButton(text, (_, _) => click(), 0);
        button.Dock = DockStyle.Fill;
        button.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        button.Margin = new Padding(10);
        button.BackColor = Color.White;
        button.ForeColor = Color.FromArgb(29, 63, 111);
        grid.Controls.Add(button, column, row);
    }

    private static Button MakeButton(string text, EventHandler click, int width)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = width > 0,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            MinimumSize = width > 0 ? new Size(width, 45) : Size.Empty,
            Width = width,
            Height = 45,
            Margin = new Padding(4),
            BackColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            ForeColor = Color.FromArgb(35, 55, 80),
            Cursor = Cursors.Hand,
            TextAlign = ContentAlignment.MiddleCenter,
            UseCompatibleTextRendering = true,
            Padding = width > 0 ? new Padding(14, 3, 14, 3) : new Padding(6, 3, 6, 3)
        };
        button.FlatAppearance.BorderColor = Color.FromArgb(181, 194, 211);
        button.Click += click;
        return button;
    }

    private sealed record ConnectionAttempt(bool Connected, bool StartedLocalDb, bool ServerReachable, string EffectiveServer, string Error);

    private const string TriggerInsertSql = @"
SET XACT_ABORT ON;
BEGIN TRAN;
INSERT dbo.Muon (isbn, ma_cuonsach, ma_DocGia, ngay_muon, ngay_hethan)
VALUES ('ISBN001', 2, 2, CONVERT(date, GETDATE()), DATEADD(DAY, 14, CONVERT(date, GETDATE())));
SELECT cs.isbn, cs.ma_cuonsach, cs.tinhtrang AS TinhTrangCuon, ds.trangthai AS TrangThaiDauSach
FROM dbo.Cuonsach cs INNER JOIN dbo.Dausach ds ON ds.isbn = cs.isbn
WHERE cs.isbn = 'ISBN001' AND cs.ma_cuonsach = 2;
ROLLBACK;";

    private const string TriggerDeleteSql = @"
SET XACT_ABORT ON;
BEGIN TRAN;
DELETE dbo.Muon WHERE isbn = 'ISBN002' AND ma_cuonsach = 1;
SELECT cs.isbn, cs.ma_cuonsach, cs.tinhtrang AS TinhTrangCuon, ds.trangthai AS TrangThaiDauSach
FROM dbo.Cuonsach cs INNER JOIN dbo.Dausach ds ON ds.isbn = cs.isbn
WHERE cs.isbn = 'ISBN002' AND cs.ma_cuonsach = 1;
ROLLBACK;";

    private const string TriggerUpdateSql = @"
SET XACT_ABORT ON;
BEGIN TRAN;
UPDATE dbo.Cuonsach SET tinhtrang = 'no' WHERE isbn = 'ISBN001' AND ma_cuonsach = 2;
SELECT cs.isbn, cs.ma_cuonsach, cs.tinhtrang AS TinhTrangCuon, ds.trangthai AS TrangThaiDauSach
FROM dbo.Cuonsach cs INNER JOIN dbo.Dausach ds ON ds.isbn = cs.isbn
WHERE cs.isbn = 'ISBN001' AND cs.ma_cuonsach = 2;
ROLLBACK;";

    private const string TriggerNotifySql = @"
SET XACT_ABORT ON;
BEGIN TRAN;
INSERT dbo.Tuasach (tuasach, tacgia, tomtat)
VALUES (N'Tựa sách kiểm tra trigger', N'Tác giả kiểm tra', N'Bản ghi chỉ tồn tại trong giao dịch test.');
SELECT TOP (1) ma_tuasach, tuasach, tacgia
FROM dbo.Tuasach ORDER BY ma_tuasach DESC;
ROLLBACK;";

    private const string SchoolConstraintTestSql = @"
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRAN;
    INSERT dbo.PC_COI_THI (MAGV, HK, NGAY, GIO, PHG)
    VALUES ('GV001', 1, '2026-09-15', '07:30', 'A101');
    SELECT N'Không đúng: thao tác đáng lẽ phải bị từ chối.' AS KetQua;
    ROLLBACK;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK;
    SELECT N'Đã chặn đúng bởi ràng buộc: ' + ERROR_MESSAGE() AS KetQua;
END CATCH;";
}
