namespace CuoiKyWinForms;

public sealed class ExerciseMenuForm : Form
{
    private readonly ExerciseOption[] _options;

    public ExerciseMenuForm(string title, string description, params ExerciseOption[] options)
    {
        Text = title;
        _options = options;
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(860, Math.Min(820, 220 + options.Length * 94));
        MinimumSize = new Size(680, 380);
        Font = new Font("Segoe UI", 10F);
        BackColor = Color.FromArgb(246, 248, 251);
        BuildLayout(title, description);
    }

    private void BuildLayout(string title, string description)
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Padding = new Padding(18),
            BackColor = BackColor
        };
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        var heading = new Panel { Dock = DockStyle.Fill, Height = 98 };
        heading.Controls.Add(new Label
        {
            Text = title,
            AutoSize = true,
            Font = new Font("Segoe UI", 16F, FontStyle.Bold),
            ForeColor = Color.FromArgb(29, 63, 111),
            Location = new Point(0, 0)
        });
        heading.Controls.Add(new Label
        {
            Text = description,
            AutoSize = false,
            Width = 780,
            Height = 48,
            ForeColor = Color.FromArgb(80, 88, 101),
            Location = new Point(0, 50)
        });
        root.Controls.Add(heading, 0, 0);

        var scroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true };
        var choices = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            ColumnCount = 1,
            RowCount = _options.Length,
            Padding = new Padding(0, 4, 0, 4)
        };
        choices.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        for (var index = 0; index < _options.Length; index++)
        {
            var option = _options[index];
            choices.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
            var button = new Button
            {
                Text = $"{option.Label}\n{option.Description}",
                Dock = DockStyle.Fill,
                Margin = new Padding(2, 4, 2, 4),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                ForeColor = Color.FromArgb(35, 55, 80),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(16, 4, 16, 4),
                UseCompatibleTextRendering = true,
                Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(181, 194, 211);
            button.Click += (_, _) => option.Open(this);
            choices.Controls.Add(button, 0, index);
        }

        scroll.Controls.Add(choices);
        root.Controls.Add(scroll, 0, 1);
    }
}
