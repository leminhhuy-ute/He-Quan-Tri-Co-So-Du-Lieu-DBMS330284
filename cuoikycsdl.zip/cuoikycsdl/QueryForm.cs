using System.Data;
using Microsoft.Data.SqlClient;

namespace CuoiKyWinForms;

public sealed class QueryForm : Form
{
    private readonly string _server;
    private readonly string _database;
    private readonly string _sql;
    private readonly QueryParameter[] _parameters;
    private readonly Dictionary<string, TextBox> _inputs = new(StringComparer.OrdinalIgnoreCase);
    private readonly DataGridView _grid = new();
    private readonly Label _status = new();

    public QueryForm(
        string title,
        string server,
        string database,
        string sql,
        string description,
        params QueryParameter[] parameters)
    {
        Text = title;
        _server = server;
        _database = database;
        _sql = sql;
        _parameters = parameters;
        StartPosition = FormStartPosition.CenterParent;
        Size = new Size(1120, 720);
        MinimumSize = new Size(760, 520);
        WindowState = FormWindowState.Maximized;
        MaximizeBox = true;
        Font = new Font("Segoe UI", 10F);
        BuildLayout(description);
    }

    private void BuildLayout(string description)
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 5,
            Padding = new Padding(14),
            BackColor = Color.FromArgb(246, 248, 251)
        };
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 112));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        root.Controls.Add(new Label
        {
            Text = description,
            AutoSize = true,
            MaximumSize = new Size(1020, 0),
            ForeColor = Color.FromArgb(35, 55, 80),
            Padding = new Padding(0, 0, 0, 8)
        }, 0, 0);

        var inputs = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            Padding = new Padding(0, 4, 0, 4)
        };
        foreach (var parameter in _parameters)
        {
            var block = new TableLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1,
                RowCount = 2,
                MinimumSize = new Size(265, 0),
                Margin = new Padding(0, 0, 12, 4)
            };
            block.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 265));
            block.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            block.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            block.Controls.Add(new Label
            {
                Text = parameter.Label,
                AutoSize = true,
                Dock = DockStyle.Fill,
                Margin = new Padding(0, 0, 0, 7),
                Padding = new Padding(0, 2, 0, 2),
                UseCompatibleTextRendering = true
            }, 0, 0);
            var input = new TextBox
            {
                Text = parameter.DefaultValue,
                Dock = DockStyle.Fill,
                Margin = new Padding(0, 0, 0, 8)
            };
            block.Controls.Add(input, 0, 1);
            _inputs[parameter.Name] = input;
            inputs.Controls.Add(block);
        }

        var execute = new Button
        {
            Text = "Thực hiện",
            Dock = DockStyle.Fill,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            MinimumSize = new Size(165, 40),
            Margin = new Padding(0, 0, 0, 8),
            Padding = new Padding(14, 3, 14, 3),
            BackColor = Color.FromArgb(29, 91, 156),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            UseCompatibleTextRendering = true
        };
        execute.Click += async (_, _) => await ExecuteQueryAsync();

        var executeBlock = new TableLayoutPanel
        {
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1,
            RowCount = 2,
            MinimumSize = new Size(165, 0),
            Margin = new Padding(0, 0, 0, 4)
        };
        executeBlock.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 165));
        executeBlock.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        executeBlock.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        executeBlock.Controls.Add(new Label
        {
            Text = " ",
            AutoSize = true,
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 0, 7),
            Padding = new Padding(0, 2, 0, 2)
        }, 0, 0);
        executeBlock.Controls.Add(execute, 0, 1);
        inputs.Controls.Add(executeBlock);
        root.Controls.Add(inputs, 0, 1);

        var codeBox = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BorderStyle = BorderStyle.FixedSingle,
            BackColor = Color.White,
            ForeColor = Color.FromArgb(35, 55, 80),
            Font = new Font("Consolas", 9.5F),
            Text = _sql,
            ScrollBars = RichTextBoxScrollBars.Vertical
        };
        root.Controls.Add(codeBox, 0, 2);

        _status.Text = $"CSDL: {Db.DatabaseDisplayName(_database)}";
        _status.AutoSize = true;
        _status.Padding = new Padding(0, 8, 0, 8);
        _status.ForeColor = Color.FromArgb(80, 88, 101);
        root.Controls.Add(_status, 0, 3);

        _grid.Dock = DockStyle.Fill;
        _grid.ReadOnly = true;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
        _grid.ScrollBars = ScrollBars.Both;
        _grid.AllowUserToResizeColumns = true;
        _grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
        _grid.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
        _grid.RowHeadersVisible = false;
        _grid.BackgroundColor = Color.White;
        _grid.BorderStyle = BorderStyle.FixedSingle;
        root.Controls.Add(_grid, 0, 4);

        Shown += async (_, _) => await ExecuteQueryAsync();
    }

    private async Task ExecuteQueryAsync()
    {
        try
        {
            _status.Text = $"Đang kết nối và chạy truy vấn... {Db.DatabaseDisplayName(_database)}";
            _status.ForeColor = Color.FromArgb(80, 88, 101);
            using var connection = Db.CreateConnection(_server, _database);
            using var command = new SqlCommand(_sql, connection)
            {
                CommandType = CommandType.Text,
                CommandTimeout = 60
            };
            foreach (var parameter in _parameters)
                AddParameter(command, parameter, _inputs[parameter.Name].Text);

            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();
            var table = new DataTable();
            table.Load(reader);
            _grid.DataSource = table;
            _status.Text = $"Đã chạy xong. Số dòng: {table.Rows.Count}. {Db.DatabaseDisplayName(_database)}";
            _status.ForeColor = Color.FromArgb(25, 120, 70);
        }
        catch (Exception ex)
        {
            _grid.DataSource = null;
            _status.Text = $"Lỗi: {ex.Message}";
            _status.ForeColor = Color.Firebrick;
        }
    }

    private static void AddParameter(SqlCommand command, QueryParameter definition, string rawValue)
    {
        var parameter = definition.Size > 0
            ? command.Parameters.Add(definition.Name, definition.Type, definition.Size)
            : command.Parameters.Add(definition.Name, definition.Type);

        if (definition.Type == SqlDbType.Decimal)
        {
            parameter.Precision = definition.Precision == 0 ? (byte)18 : definition.Precision;
            parameter.Scale = definition.Scale == 0 ? (byte)6 : definition.Scale;
        }

        parameter.Value = definition.Type switch
        {
            SqlDbType.Int => int.TryParse(rawValue, out var intValue)
                ? intValue
                : throw new FormatException($"{definition.Label} phải là số nguyên."),
            SqlDbType.Decimal => decimal.TryParse(rawValue, out var decimalValue)
                ? decimalValue
                : throw new FormatException($"{definition.Label} phải là số."),
            SqlDbType.Date => DateTime.TryParse(rawValue, out var dateValue)
                ? dateValue.Date
                : throw new FormatException($"{definition.Label} phải là ngày hợp lệ."),
            _ => rawValue.Trim()
        };
    }
}
